console.log("hi")

// const backendURL = "http://localhost:8080/api/v1"
const backendURL = "http://122.248.201.55:8080/api/v1"
// const loginToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFjY2VudHVyZSIsImlhdCI6MTY4NjI3NjYwNn0.TUAmvtcDNk6Q9RioxyySfvfch_MPimGz7O2KwYYP7jE"
const loginToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFjY2VudHVyZSIsImlhdCI6MTY4NjI4Mjc0MX0.72cZoasvRf8OD1T4scSMlBEClkPH2QUXoK2or1jkbvY"

var statusdiv = document.getElementById('statusdiv');
console.log(statusdiv)

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function preFirstActivity() {
    statusdiv.textContent = "0,-1: checking if correct page"

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into opportunities
                // click the 3rd breadcrumb link
                // document.getElementsByClassName("breadcrumb_LINK")[2].click();

                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let counter;
                let paused = true;

                counter = fetch('http://localhost:5001/getcounterstatic')
                    .then(function (response) {
                        if (response.ok) {
                            return response.text();
                        }
                        throw new Error('Network response was not ok.');
                    })
                    .then(function (data) {
                        // data is the counter
                        paused = false;
                        counter = data;
                        return data;
                    }
                    );

                while (paused) {

                    await sleep(300);
                    console.log("paused as waiting for counter")
                }


                counter = parseInt(counter)



                let lastItemNumberInPage = parseInt(document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER")[document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER").length - 1].textContent);
                console.log(lastItemNumberInPage + " is last item number in page")
                console.log(counter + "is the counter");

                let numberOfInvitedOpportunities = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent.split("results")[0];
                numberOfInvitedOpportunities = parseInt(numberOfInvitedOpportunities.trim());

                if (numberOfInvitedOpportunities < counter) {
                    return false;
                }

                return lastItemNumberInPage < counter;
            }
        }, async function (result) {

            try {
                if (result[0].result == true) {
                    statusdiv.textContent = "0,1: need to click next page";
                } else if (result[0].result == false) {
                    statusdiv.textContent = "0,0: correct page le";
                } else if (result[0].result == null) {
                    statusdiv.textContent = "0,: no check done, need to check again";
                }
            } catch {
                statusdiv.textContent = "0,: no check done, need to check again";
            }



        })
    });


}

async function clickNextOpportunityPage() {

    statusdiv.textContent = "0,0,0: clicking into next opportunity page..."


    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into opportunities
                // click the 3rd breadcrumb link
                // document.getElementsByClassName("breadcrumb_LINK")[2].click();

                for (var i = 0; i < document.getElementsByTagName("input").length; i++) {
                    if (document.getElementsByTagName("input")[i].value == "Next") {
                        document.getElementsByTagName("input")[i].click();
                        break;
                    }
                }
            }
        }, async function (result) {

            statusdiv.textContent = "0,2: click next page le";

        })
    });


}

async function firstActivity() { // go into first opportunity
    statusdiv.textContent = "0: trying to click into the tender..."
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // call runserver to get counter
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                console.log("first activity here")
                let counter;
                let paused = true;
                counter = fetch('http://localhost:5001/getcounterstatic')
                    .then(function (response) {
                        if (response.ok) {
                            return response.text();
                        }
                        throw new Error('Network response was not ok.');
                    })
                    .then(function (data) {
                        // data is the counter
                        paused = false;
                        counter = data;
                        return data;
                    }
                    );

                while (paused) {
                    await sleep(300);
                    console.log("paused as waiting for counter")
                    continue;
                }


                counter = parseInt(counter)
                let numberOfInvitedOpportunities = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent.split("results")[0];
                numberOfInvitedOpportunities = parseInt(numberOfInvitedOpportunities.trim());
                // let numberOfInvitedOpportunities = 38

                if (numberOfInvitedOpportunities < counter) {
                    return { 0: false, 1: numberOfInvitedOpportunities }; // means all opportunities checked
                }



                while (parseInt(document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER")[document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER").length - 1].textContent) < counter) {
                    if (document.getElementsByClassName("formRepeatPagination2_NAVIGATION-BUTTON-CURRENT")[0].value == oldPageNumber) {
                        // implement loading handling here
                        await sleep(300);
                        console.log("sleep 1s")
                        continue;
                    }

                    oldPageNumber = document.getElementsByClassName("formRepeatPagination2_NAVIGATION-BUTTON-CURRENT")[0].value;
                    // click next button
                    // iterate through input elements, find value "Next"
                    for (var i = 0; i < document.getElementsByTagName("input").length; i++) {
                        if (document.getElementsByTagName("input")[i].value == "Next") {
                            document.getElementsByTagName("input")[i].click();
                            break;
                        }
                    }
                    await sleep(300);
                }
                console.log("correct page already")
                let equalizer;
                // iterate through the numbers
                for (let i = 0; i < document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER").length; i++) {
                    if (parseInt(document.getElementsByClassName("formSectionHeader6_SERIAL-NUMBER")[i].textContent) == counter) {
                        equalizer = i;
                        break;
                    }
                }
                console.log(equalizer + " is equalizer")
                document.getElementsByClassName("commandLink_TITLE-BLUE")[equalizer].click();

                // get opportunity id from class: formSectionHeader6_TEXT, separated by " - ", then get second element
                var oppid = document.getElementsByClassName("formSectionHeader6_TEXT")[counter].textContent.split(" - ")[1];

                return { 0: true, 1: 0 };

            }
        }, function (result) { // set last download to last download

            console.log(result)
            console.log(result[0].result)
            if (result[0].result[0] == false) {
                statusdiv.textContent = "1:" + result[0].result[0];
                document.getElementById("urlmsg").textContent = "Fully extracted " + result[0].result[1] + " invited opportunities.";
                return;
            }


        });
    });
}

async function Option1firstActivity() { // go into first opportunity
    statusdiv.textContent = "0: trying to click into the tender..."
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // call runserver to get counter
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                console.log("first activity here")
                let counter;
                let paused = true;
                counter = fetch('http://localhost:5001/getID')
                    .then(function (response) {
                        if (response.ok) {
                            return response.text();
                        }
                        throw new Error('Network response was not ok.');
                    })
                    .then(function (data) {
                        // data is the counter
                        paused = false;
                        counter = data;
                        return data;
                    }
                    );

                while (paused) {
                    await sleep(300);
                    console.log("paused as waiting for counter")
                    continue;
                }


                
                // navigate to page according to the type selected
                // if invitations: https://www.gebiz.gov.sg/ptn/invitations/details.xhtml?docCode=MHASPF03000018445
                // if responses: https://www.gebiz.gov.sg/ptn/response/ResponseListingView.xhtml?code=MHA00003000017278
                // if opportunities: https://www.gebiz.gov.sg/ptn/opportunity/directlink.xhtml?docCode=TPO000ETQ23000166
                // https://www.gebiz.gov.sg/ptn/opportunity/directlink.xhtml?docCode=HDB000ETT23000178

                // get selected radio button from name options
                // 123abc separated
                let counter_splitted = counter.split("123abc");


                let opportunitytype = counter_splitted[0];
                let opportunity_id = counter_splitted[1];
                let url;
                if (opportunitytype == "Invitations") {
                    url = "https://www.gebiz.gov.sg/ptn/invitations/details.xhtml?docCode=";
                } else if (opportunitytype == "Responses") {
                    url = "https://www.gebiz.gov.sg/ptn/response/ResponseListingView.xhtml?code=";
                } else if (opportunitytype == "Opportunities") {
                    url = "https://www.gebiz.gov.sg/ptn/opportunity/directlink.xhtml?docCode=";
                }


                url = url + opportunity_id;

                // navigate to url
                window.location.href = url;



                return { 0: true, 1: 0 };

            }
        }, function (result) { // set last download to last download

            console.log(result)
            console.log(result[0].result)
            if (result[0].result[0] == false) {
                statusdiv.textContent = "1:" + result[0].result[0];
                document.getElementById("urlmsg").textContent = "Fully extracted " + result[0].result[1] + " invited opportunities.";
                return;
            }


        });
    });
}

async function checkIfTabLoading() {
    statusdiv.textContent = "0s: checking if page started loading"
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // if tab is still loading, return false
        if (tabs[0].status == "loading") {
            statusdiv.textContent = "0l: page started loading..."
        } else {
            statusdiv.textContent = "0h: page havent started loading..."
        }
    });
}

async function Option1CheckPostFirst() {
    statusdiv.textContent = "1p: checking if page is loaded correctly..."
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // if tab is still loading, return false
        if (tabs[0].status == "loading") {
            statusdiv.textContent = "1: page is still loading..."
            return;
        }


        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order

                

                
                if (document.getElementsByClassName("formOutputText_VALUE-DIV").length == 0) {
                    return false;
                }
                if (document.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent.length <= 5) {
                    return document.getElementsByClassName("formOutputText_VALUE-DIV")[1].textContent
                }
                return document.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent


            }
        }, function (result) { // set last download to last download

            if (result[0].result == false) {
                statusdiv.textContent = "1: Page not loaded correctly"
                return;
            }

            if (result[0].result == null) {
                statusdiv.textContent = "1: did not manage to check the opportunity id"
                return;
            }

            statusdiv.textContent = "1c:" + result[0].result




        });
    });
}
                

async function checkSpecial() {
    statusdiv.textContent = "1.8.0: checking if special opportunity"


    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into opportunities
                // click the 3rd breadcrumb link
                // document.getElementsByClassName("breadcrumb_LINK")[2].click();

                return document.getElementsByClassName("formTabBar_TAB-BUTTON-ACTIVE")[0].value.includes("Overview")
            }
        }, async function (result) {

            if (result[0].result == null) {
                statusdiv.textContent = "1,-8: 1st page dk if is overview, check again";
                return;
            }

            if (result[0].result == true) {
                statusdiv.textContent = "1.8: 1st page is overview";
            } else {
                statusdiv.textContent = "1.-8: 1st page is not overview";
            }

        })
    });

}

async function five2SpecialActivity() { // executed if special only awards page
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order

                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let awards = []

                while (document.getElementsByClassName("formTabBar_TAB-BUTTON-ACTIVE")[0].value.slice(0, 5) != "Award") {
                    await sleep(300);
                    continue;
                }

                // extract awards
                // extract awards
                let numberOfAwards = 1;
                try {
                    numberOfAwards = parseInt(document.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent);
                } catch {
                    
                }

    

                if (numberOfAwards == 1) {
                    for (let i = 0; i < numberOfAwards; i++) {
                        let awarded_company = document.getElementsByClassName("outputText_TITLE-BLACK")[2].textContent;
                        let awarded_amt = document.getElementsByClassName("formOutputText_VALUE-DIV")[3].textContent;
                        let awarded_dt = document.getElementsByClassName("formOutputText_VALUE-DIV")[2].textContent;
                        let tender_id = document.getElementsByClassName("formOutputText_VALUE-DIV")[1].textContent;
                        let month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }
    
    
                        awarded_amt = awarded_amt.replaceAll(/\([^()]*\)/g, '');
                        awarded_amt = awarded_amt.replaceAll(",", '');
                        awarded_amt = awarded_amt.trim();
    
    
                        let awarded_dt_split = awarded_dt.split(" ")
                        let awarded_dt_new = awarded_dt_split[2] + "-" + month_mapping[awarded_dt_split[1]] + "-" + awarded_dt_split[0]
    
                        let award_dict = {
                            "TENDER_ID": tender_id,
                            "AWARDED_COMPANY": awarded_company,
                            "AWARDED_AMT": awarded_amt,
                            "AWARDED_DT": awarded_dt_new
                        }
    
                        awards.push(award_dict)
    
    
    
                    }
                } else {

                
                    for (let i = 0; i < numberOfAwards; i++) {
                        let awarded_company = document.getElementsByClassName("formRepeat_MAIN")[0].getElementsByClassName("formOutputText_HIDDEN-LABEL outputText_TITLE-BLACK")[i*3].textContent;
                        let awarded_amt = document.getElementsByClassName("formRepeat_MAIN")[0].getElementsByClassName("formOutputText_HIDDEN-LABEL outputText_TITLE-BLACK")[i*3].parentElement.parentElement.parentElement.parentElement.parentElement.nextSibling.nextSibling.getElementsByClassName("formOutputText_VALUE-DIV ")[0].textContent;
                        let awarded_dt = document.getElementsByClassName("formOutputText_VALUE-DIV")[2].textContent;
                        let tender_id = document.getElementsByClassName("formOutputText_VALUE-DIV")[1].textContent;
                        let month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }


                        awarded_amt = awarded_amt.replaceAll(/\([^()]*\)/g, '');
                        awarded_amt = awarded_amt.replaceAll(",", '');
                        awarded_amt = awarded_amt.trim();


                        let awarded_dt_split = awarded_dt.split(" ")
                        let awarded_dt_new = awarded_dt_split[2] + "-" + month_mapping[awarded_dt_split[1]] + "-" + awarded_dt_split[0]

                        let award_dict = {
                            "TENDER_ID": tender_id,
                            "AWARDED_COMPANY": awarded_company,
                            "AWARDED_AMT": awarded_amt,
                            "AWARDED_DT": awarded_dt_new
                        }

                        awards.push(award_dict)
                    }
                }

                let new_name_mapping = {
                    'TENDER_ID': 'Tender No.',
                    'REFERENCE_NO': 'Reference No.',
                    'AGENCY': 'Agency',
                    'PUBLISHED_DT': 'Published',
                    'OFFER_VALIDITY_DURATION': 'Offer Validity Duration',
                    'REMARKS': 'Remarks',
                    'PROCUREMENT_TYPE': 'Procurement Type',
                    'TWO_ENVELOPE_BIDDING': 'Two Envelope Bidding',
                    'QUOTATION_TENDER_TYPE': 'Tender Type',
                    'COVERED_UNDER_WTO_GPA_FTA': 'Covered under WTO-GPA/FTA',
                    'PROCUREMENT_NATURE': 'Procurement Nature',
                    'PERIOD_CONTRACT_START_DT': 'Period Contract Start Date',
                    'PERIOD_CONTRACT_END_DT': 'Period Contract End Date',
                    'PROCUREMENT_METHOD': 'Procurement Method',
                    'REQUEST_FOR_PROPOSAL': 'Request for Proposal',
                    'GRA_SUPPLY_WORK_HEADS': 'GRA Supply/Work Heads [Tendering Capacity]',
                    'PROCUREMENT_CATEGORY': 'Procurement Category',
                    'STATUS': 'Status',
                }

                let tender_id = document.getElementsByClassName("formOutputText_VALUE-DIV")[1].textContent;
                let covered_under_wto_gpa_fta = document.getElementsByClassName("formOutputText_VALUE-DIV")[4].textContent;
                let procurement_method = document.getElementsByClassName("formOutputText_VALUE-DIV")[5].textContent;
                let agency = document.getElementsByClassName("outputText_TITLE-BLACK")[1].textContent;
                let status = "Awarded";
                let type_of_opportunity = "Tender - Non Period Contract";
                let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;

                let opp_dict = {
                    "TENDER_ID": tender_id,
                    "TENDER_NME": tender_name,
                    "COVERED_UNDER_WTO_GPA_FTA": covered_under_wto_gpa_fta,
                    "PROCUREMENT_METHOD": procurement_method,
                    "AGENCY": agency,
                    "STATUS": status,
                    "TYPE_OF_OPPORTUNITY": type_of_opportunity,
                    "PUBLISHED_DT": awards[0]["AWARDED_DT"],
                    "END_DT": awards[0]["AWARDED_DT"]
                }


                return [opp_dict, awards];
            }
        }, async function (result) {
            console.log("awards here:" + JSON.stringify(result[0].result[1]))
            console.log("opportunity here:" + JSON.stringify(result[0].result[0]))
            statusdiv.textContent = "5.2: extracted awards";

            async function sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }

            let request_dict = result[0].result[0];
            var request_dict1 = result[0].result[1];

            await fetch(`${backendURL}/opportunity`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "5.2z: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );

            while (statusdiv.textContent.slice(0, 5) != "5.2z:") {
                await sleep(300);
                continue;
            }


            // send request_dict to server here
            await fetch(`${backendURL}/award`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict1),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "5.2a: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") {
                await sleep(5000);
                if (statusdiv.textContent.slice(0, 4) == "5.2:") {
                    statusdiv.textContent = "5.2z: retry send awards over"
                    console.log(request_dict1)
                    await fetch(`${backendURL}/award`, {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + loginToken,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(request_dict1),
                    })
                        .then(data => {
                            console.log('Success:', data);
                            // if success returned...
                            if (data.status == 200 || data.status == 201) {
                                statusdiv.textContent = "5.2a: " + data;
                            } else {
                                statusdiv.textContent = "5.2: Server may be down: \n" + error;
                            }
                        })
                        .catch((error) => {
                            console.error('Error:', error);
                            statusdiv.textContent = "5.2: Server may be down: \n" + error;
                        }
                        );
                }
                continue;
            }

        })
    }
    );


}

async function second0Activity() { // hold last download
    chrome.downloads.search({ limit: 1, orderBy: ['-startTime'] }, function (downloadItems) {
        document.getElementById("lastdownloadholder").textContent = downloadItems[0].filename;
    });

    statusdiv.textContent = "1.9: finished checking last download: " + document.getElementById("lastdownloadholder").textContent;

}

async function secondActivity() { // click download all button
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("second activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }
                let counter = 0;
                while (document.getElementsByClassName("formAttachmentsList_DOWNLOAD-BUTTON").length == 0) {
                    await sleep(300);
                    counter++;
                    if (counter > 11) {
                        console.log("no download button found!");
                        return -1
                    }
                    console.log("waiting for download button")
                }

                await sleep(300);
                document.getElementsByClassName("formAttachmentsList_DOWNLOAD-BUTTON")[0].click();
                console.log("clicked download button");



                return document.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent // opp id
            }
        }, function (result) {
            if (result[0].result == -1) {
                statusdiv.textContent = "2,-1: no download button found after >30s!";
            } else {
                statusdiv.textContent = "2:" + result[0].result;
                document.getElementById("idholder").innerHTML = result[0].result;
            }

        });
    });
}

async function fixsecondActivity() { // click the first file
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                document.getElementsByClassName("formAttachmentsList_DOCUMENT-LINK")[0].click()
            }
        }, function (result) {
        });
    });

}

async function thirdActivity() { // check if download is complete
    // upload downloaded file to backend
    chrome.downloads.search({ limit: 1, orderBy: ['-startTime'] }, async function (downloadItems) {

        if (downloadItems[0].filename == document.getElementById("lastdownloadholder").textContent) {
            console.log("waiting for download")
            statusdiv.textContent = "2 : Waiting for download to start... (download button may be spoilt if it is taking long)"
            return;
        }

        statusdiv.textContent = "2:1." + downloadItems[0].filename;
        // while status is not complete, sleep
        if (downloadItems[0].state != "complete") {
            console.log("download not complete")
            statusdiv.textContent = "2 : Waiting for download to complete..."
            return false;
        }
        statusdiv.textContent = "3:" + downloadItems[0].filename;

        document.getElementById("lastdownloadholder1").textContent = downloadItems[0].filename;




    });
}


async function fourthActivity() { // send file to backend

    chrome.downloads.search({ limit: 1, orderBy: ['-startTime'] }, async function (downloadItems) {

        // sending get request to runserver.py
        var url = 'http://localhost:5001/sendfile';
        statusdiv.textContent = "3.8:" + "trying to send downloaded file over";
        let sendfilestring = downloadItems[0].filename;
        sendfilestring = sendfilestring.replaceAll("&", "%26");
        fetch(url + "?filename=" + sendfilestring)
            .then(function (response) {
                if (response.ok) {
                    return response.text();
                }
                throw new Error('Network response was not ok.');
            })
            .then(function (data) {
                // Process the data here

                fetch('http://localhost:5001/deletefile?filename=' + sendfilestring)
                    .then(function (response) {
                        statusdiv.textContent = "4:" + " sent and deleted file";
                    })

            })
            .catch(function (error) {
                console.log('Error:', error.message);
                statusdiv.textContent = "3.9:" + "trying to send downloaded file over";
            });


    }
    );
}

async function fourth1Activity() { // check if got multiple pages of download all
    // check if document.getElementsByClassName("formRepeatPagination_NAVIGATION-BUTTON")[2] is disabled
    // go into current tab
    statusdiv.textContent = "4,1: Checking if got more download pages"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("fourth 1 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }
                try {
                    if (document.getElementsByClassName("formAttachmentsList_DOWNLOAD-BUTTON").length == 0) {
                        return 0;
                    }
                    if (!document.getElementsByClassName("formAttachmentsList_DOWNLOAD-BUTTON")[0].textContent.includes('Download All (Page') || document.getElementsByClassName("formRepeatPagination_NAVIGATION-BUTTON")[2].disabled == true) {
                        return 0;
                    }
                }
                catch {
                    if (document.getElementsByClassName("formAttachmentsList_DOWNLOAD-BUTTON").length > 0) {
                        return 0;
                    }
                    return -1;
                }


                document.getElementsByClassName("formRepeatPagination_NAVIGATION-BUTTON")[2].click();

                return 1
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4.-1: waiting for download documents to appear!"
                    return
                }
                if (result[0].result == 0) {
                    document.getElementById("multidownloadholder").textContent += document.getElementById("lastdownloadholder1").textContent + ";"
                    statusdiv.textContent = "4.2: No more to download!"
                    return
                }
                if (result[0].result == 1) {
                    document.getElementById("multidownloadholder").textContent += document.getElementById("lastdownloadholder1").textContent + ";"
                    statusdiv.textContent = "4.1: Got more download pages"
                }
            }
            catch {
                // pass
                document.getElementById("multidownloadholder").textContent += document.getElementById("lastdownloadholder1").textContent + ";"
                statusdiv.textContent = "4.1: Got more download pages"
            }



        });
    });
}

async function corrigendumActivity() { // download all corrigendum documents

    statusdiv.textContent = "4,4,1: Checking if got corrigendum docs"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }
                try {
                    if (document.getElementsByClassName("formColumns_COLUMN-TABLE")[3].getElementsByClassName("formSectionHeader1_TEXT")[0].textContent == "CORRIGENDUM") {
                        // count how many view corrigendum buttons there are
                        let corributtoncount = 0;
                        // iterate through document.getElementsByClassName("commandButton_BIG").length
                        for (var i = 0; i < document.getElementsByClassName("commandButton_BIG").length; i++) {
                            if (document.getElementsByClassName("commandButton_BIG")[i].value == "View Corrigendum Documents") {
                                corributtoncount += 1;
                            }
                        }
                        return corributtoncount;
                    }
                    else {
                        return -1;
                    }
                }
                catch {
                    return -1;
                }



                return 1
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4,4,-1: No view corrigendum documents button!"
                    return
                }
                statusdiv.textContent = "4,4,2: number of view corrigendum documents button:" + result[0].result
                document.getElementById("corrigendumcount").textContent = result[0].result;
            }
            catch {
                // pass
            }


        });
    });


}



async function corrigendum1Activity() { // download all corrigendum documents

    statusdiv.textContent = "4,6,1: clicking into corrigendum docs"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum 1 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let corricounter;
                let paused = true;
                corricounter = fetch('http://localhost:5001/checkcorricounter')
                    .then(function (response) {
                        if (response.ok) {
                            return response.text();
                        }
                        throw new Error('Network response was not ok.');
                    })
                    .then(function (data) {
                        // data is the counter
                        paused = false;
                        corricounter = data;
                        return data;
                    }
                    );

                while (paused) {
                    await sleep(300);
                    console.log("paused as waiting for corricounter")
                    continue;
                }


                corricounter = parseInt(corricounter)

                let nthbutton = 0;
                for (var i = 0; i < document.getElementsByClassName("commandButton_BIG").length; i++) {
                    if (document.getElementsByClassName("commandButton_BIG")[i].value == "View Corrigendum Documents") {
                        nthbutton += 1;
                        if (nthbutton == corricounter) {
                            document.getElementsByClassName("commandButton_BIG")[i].click();
                            await sleep(300);
                            return 0;
                            break;
                        }
                    }
                }



                return -1
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4,4,-1: No view corrigendum documents button!"
                    return
                }
                statusdiv.textContent = "4,6,2: clicked into corrigendum docs"
            }
            catch {
                // pass
                statusdiv.textContent = "4,6,2: clicked into corrigendum docs"
            }


        });
    });


}

async function corrigendum2Activity() { // wait for download all

    statusdiv.textContent = "4,7,0: checking if corrigendum popup is here"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum 2 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                if (document.getElementsByClassName("formSectionHeader1_TEXT")[0].textContent.slice(0, 20) == "CORRIGENDUM DOCUMENT") {
                    return 1;
                }



                return -1
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4,7,-1: No corrigendum popup!"
                    return
                } else if (result[0].result == 1) {
                    statusdiv.textContent = "4,7,1: have corrigendum popup!"

                    chrome.downloads.search({ limit: 1, orderBy: ['-startTime'] }, async function (downloadItems) {
                        document.getElementById("lastdownloadholder").textContent = downloadItems[0].filename;
                    });

                    return

                }
            }
            catch {
                // pass
                statusdiv.textContent = "4,7,-1: No corrigendum popup!"
                return
            }
            statusdiv.textContent = "4,7,-1: No corrigendum popup!"

        });
    });


}

async function corrigendum3Activity() { // download all corrigendum documents

    statusdiv.textContent = "4,8,1: Downloading corrigendum docs"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum 3 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                if (document.getElementsByClassName("commandButton_BIG")[0].value == "Download All") {
                    document.getElementsByClassName("commandButton_BIG")[0].click()
                }
                else {
                    return -1;
                }



            }
        }, function (result) {
            try {
                if (result[0].result == -1) {
                    statusdiv.textContent = "4,8,-1: No download all button!"
                } else {
                    statusdiv.textContent = "4,8,2: clicked Download all corrigendum docs";
                }
            } catch {
                statusdiv.textContent = "4,8,2: clicked Download all corrigendum docs"
            }




        });
    });


}

async function fixcorrigendum3Activity() {

    statusdiv.textContent = "4,8,9: Fixing Downloading corrigendum docs"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("fix corrigendum 3 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                document.getElementsByClassName("formAttachmentsList_DOCUMENT-LINK")[0].click()


            }
        }, function (result) {
            statusdiv.textContent = "4,8,9,1: clicked first download doc";

        });
    });

}

async function corrigendum4Activity() { // download all corrigendum documents

    statusdiv.textContent = "4,9,0: seeing if download all corrigendum is starting"
    chrome.downloads.search({ limit: 1, orderBy: ['-startTime'] }, async function (downloadItems) {
        if (document.getElementById("lastdownloadholder").textContent == downloadItems[0].filename) {
            statusdiv.textContent = "4,9,1: same file name as previous, so havent start"
            return;
        }

        if (downloadItems[0].state != "complete") {
            console.log("download not complete")
            statusdiv.textContent = "4,9,2: Waiting for download to complete..."
            return;
        }

        statusdiv.textContent = "4,9,3: Downloaded corrigendum docs"
        document.getElementById("corrigendumholder").textContent += downloadItems[0].filename + ";"

    });


}


async function corrigendum5Activity() { // click close corrigendum docs

    statusdiv.textContent = "4,10,0: trying to close corrigendum docs"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum 5 activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                document.getElementsByClassName("commandButton_BIG")[1].click()

            }
        }, function (result) {

            statusdiv.textContent = "4,10,1: clicked close corrigendum docs";


        });
    });


}

async function corrigendum6Activity() { // check if successfully backed

    statusdiv.textContent = "4,11,0: checking if loaded"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("corrigendum 6 activity here")

                if (document.getElementsByClassName("label_MAIN").length > 0) {
                    return 1;
                }

                return -1;

            }
        }, function (result) {
            try {
                if (result[0].result == -1) {
                    statusdiv.textContent = "4,11,-1: Not back!!"
                } else if (result[0].result == 1) {
                    statusdiv.textContent = "4,11,1: back to the opportunity!";
                } else if (result[0].result == null) {
                    statusdiv.textContent = "4,11,-1: Not back!!"
                }
            } catch {
                statusdiv.textContent = "4,11,-1: Not back!!"
            }

            

        });
    });


}





async function fifthActivity() { // return html of page
    // go into current tab
    statusdiv.textContent = "5s: getting html of page"

    async function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    await sleep(300);
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                console.log("fifth activity here")

                // handle corrigendum html text here
                let corrigendum_html = null;
                if (document.getElementsByClassName("formColumns_COLUMN-TABLE")[3].getElementsByClassName("formSectionHeader1_TEXT")[0].textContent == "CORRIGENDUM") {
                    corrigendum_html = document.getElementsByClassName("formColumns_COLUMN-TABLE")[3].innerHTML;
                    // clean corrigendum html by trimming <div ...> to <div> using regex
                    corrigendum_html = corrigendum_html.replaceAll(/<div[^>]*>/g, "<div>");

                    // clean corrigendum html by removing <span ...> to </span> using regex
                    corrigendum_html = corrigendum_html.replaceAll(/<span[^>]*>/g, "");

                    // clean corrigendum html by replacing <a ...> to <a href="#" type="link">
                    corrigendum_html = corrigendum_html.replaceAll(/<a[^>]*>/g, '<a href="#" type="link">');

                    // clean corrigendum html by replacing <input ...value="View Corrigendum Documents"...> to <input type="submit" value="View Corrigendum Documents"/>
                    corrigendum_html = corrigendum_html.replaceAll(/<input[^>]*value="View Corrigendum Documents"[^>]*>/g, '<input type="submit" value="View Corrigendum Documents"/>');

                    // clean corrigendum html by removing <img> tags
                    corrigendum_html = corrigendum_html.replaceAll(/<img[^>]*>/g, "");

                    // clean corrigendum html by removing <script>...</scipt>
                    corrigendum_html = corrigendum_html.replaceAll(/<script[^>]*>[\s\S]*?<\/script>/g, "");

                }

                // extract out data and send to server
                // data to extract:

                // check cancelled
                if (document.getElementsByClassName("label_MAIN")[0].textContent == "CANCELLED") {
                    let new_name_mapping = {
                        'CANCELLATION_DATE': 'Cancellation Date',
                        'REASON_FOR_CANCELLATION': 'Reason for Cancellation',
                        'TENDER_ID': 'Quotation No.',
                        'REFERENCE_NO': 'Reference No.',
                        'AGENCY': 'Agency',
                        'PUBLISHED_DT': 'Published',
                        'OFFER_VALIDITY_DURATION': 'Offer Validity Duration',
                        'REMARKS': 'Remarks',
                        'PROCUREMENT_TYPE': 'Procurement Type',
                        'QUOTATION_TENDER_TYPE': 'Quotation Type',
                        'PROCUREMENT_NATURE': 'Procurement Nature',
                        'PROCUREMENT_METHOD': 'Procurement Method',
                        'PAYMENT_TERMS': 'Payment Terms',
                        'QUOTATION_BOX_NO': 'Quotation Box No.',
                        'PROCUREMENT_CATEGORY': 'Procurement Category',
                        'STATUS': 'Status',
                    }
                    let field_list = ["CANCELLATION_DATE", "REASON_FOR_CANCELLATION", "TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "OFFER_VALIDITY_DURATION", "REMARKS", "PROCUREMENT_TYPE", "QUOTATION_TENDER_TYPE", "PROCUREMENT_NATURE", "PROCUREMENT_METHOD", "PAYMENT_TERMS", "QUOTATION_BOX_NO", "PROCUREMENT_CATEGORY", "STATUS"]
                    let field_values = []
                    for (var i = 0; i < field_list.length - 1; i++) {
                        let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                        field_values.push(field_value)
                    }
                    let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                    field_values.push(status_field);

                    let field_dict = {}
                    for (var i = 0; i < field_list.length; i++) {
                        field_dict[field_list[i]] = field_values[i]
                    }

                    let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                    field_dict["TENDER_NME"] = tender_name;

                    field_dict["TYPE_OF_OPPORTUNITY"] = "Quotation - Cancelled"
                    field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                    let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                    // change '04 Aug 2023' to '2023-08-04' format
                    month_mapping = {
                        "Jan": "01",
                        "Feb": "02",
                        "Mar": "03",
                        "Apr": "04",
                        "May": "05",
                        "Jun": "06",
                        "Jul": "07",
                        "Aug": "08",
                        "Sep": "09",
                        "Oct": "10",
                        "Nov": "11",
                        "Dec": "12"
                    }

                    let end_dt_split = end_dt.split(" ")
                    let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                    field_dict["END_DT"] = end_dt_new

                    let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                    let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                    field_dict["PUBLISHED_DT"] = published_dt_new

                    if (corrigendum_html != null) {
                        field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                    }

                    let bids = []
                    let awards = []

                    return { 0: field_dict, 1: bids, 2: awards };
                }

                // check if is qualification
                if (document.getElementsByClassName("form2_ROW-LABEL-DIV")[0].getElementsByTagName("span")[0].textContent.slice(0, 13) == "Qualification") {
                    let new_name_mapping = {
                        'TENDER_ID': 'Qualification No.',
                        'REFERENCE_NO': 'Reference No.',
                        'AGENCY': 'Agency',
                        'PUBLISHED_DT': 'Published',
                        'REMARKS': 'Remarks',
                        'PROCUREMENT_TYPE': 'Procurement Type',
                        'COVERED_UNDER_WTO_GPA_FTA': 'Covered under WTO-GPA/FTA',
                        'QUALIFICATION_CRITERIA': 'Qualification Criteria',
                        'GRA_SUPPLY_WORK_HEADS': 'GRA Supply/Work Heads [Tendering Capacity]',
                        'PROCUREMENT_CATEGORY': 'Procurement Category',
                        'STATUS': 'Status',
                    }
                    let field_list = ["TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "REMARKS", "PROCUREMENT_TYPE", "COVERED_UNDER_WTO_GPA_FTA", "QUALIFICATION_CRITERIA", "GRA_SUPPLY_WORK_HEADS", "PROCUREMENT_CATEGORY", "STATUS"]
                    let field_values = []
                    for (var i = 0; i < field_list.length - 1; i++) {
                        let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                        field_values.push(field_value)
                    }
                    let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                    field_values.push(status_field);

                    let field_dict = {}
                    for (var i = 0; i < field_list.length; i++) {
                        field_dict[field_list[i]] = field_values[i]
                    }

                    let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                    field_dict["TENDER_NME"] = tender_name;

                    field_dict["TYPE_OF_OPPORTUNITY"] = "Qualification"
                    field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                    let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                    // change '04 Aug 2023' to '2023-08-04' format
                    month_mapping = {
                        "Jan": "01",
                        "Feb": "02",
                        "Mar": "03",
                        "Apr": "04",
                        "May": "05",
                        "Jun": "06",
                        "Jul": "07",
                        "Aug": "08",
                        "Sep": "09",
                        "Oct": "10",
                        "Nov": "11",
                        "Dec": "12"
                    }

                    let end_dt_split = end_dt.split(" ")
                    let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                    field_dict["END_DT"] = end_dt_new

                    let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                    let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                    field_dict["PUBLISHED_DT"] = published_dt_new

                    if (corrigendum_html != null) {
                        field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                    }

                    let bids = []
                    let awards = []

                    return { 0: field_dict, 1: bids, 2: awards };
                }

                // check if is request for information
                if (document.getElementsByClassName("form2_ROW-LABEL-DIV")[0].getElementsByTagName("span")[0].textContent.slice(0, 23) == "Request for Information") {
                    let new_name_mapping = {
                        'TENDER_ID': 'Request for Information No.',
                        'REFERENCE_NO': 'Reference No.',
                        'AGENCY': 'Agency',
                        'PUBLISHED_DT': 'Published',
                        'REMARKS': 'Remarks',
                        'PROCUREMENT_TYPE': 'Procurement Type',
                        'PROCUREMENT_METHOD': 'Procurement Method',
                        'RFI_REQUIREMENT': 'Request for Information Requirement / Criteria',
                        'PROCUREMENT_CATEGORY': 'Procurement Category',
                        'STATUS': 'Status',
                    }
                    let field_list = ["TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "REMARKS", "PROCUREMENT_TYPE", "PROCUREMENT_METHOD", "RFI_REQUIREMENT", "PROCUREMENT_CATEGORY", "STATUS"]
                    let field_values = []

                    for (var i = 0; i < field_list.length - 1; i++) {
                        let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                        field_values.push(field_value)
                    }
                    let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                    field_values.push(status_field);

                    let field_dict = {}
                    for (var i = 0; i < field_list.length; i++) {
                        field_dict[field_list[i]] = field_values[i]
                    }

                    let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                    field_dict["TENDER_NME"] = tender_name;

                    field_dict["TYPE_OF_OPPORTUNITY"] = "Request for Information"
                    field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                    let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                    // change '04 Aug 2023' to '2023-08-04' format
                    month_mapping = {
                        "Jan": "01",
                        "Feb": "02",
                        "Mar": "03",
                        "Apr": "04",
                        "May": "05",
                        "Jun": "06",
                        "Jul": "07",
                        "Aug": "08",
                        "Sep": "09",
                        "Oct": "10",
                        "Nov": "11",
                        "Dec": "12"
                    }

                    let end_dt_split = end_dt.split(" ")
                    let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                    field_dict["END_DT"] = end_dt_new

                    let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                    let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                    field_dict["PUBLISHED_DT"] = published_dt_new

                    if (corrigendum_html != null) {
                        field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                    }

                    let bids = []
                    let awards = []

                    return { 0: field_dict, 1: bids, 2: awards };
                }


                let opp_string = document.getElementsByClassName("form2_ROW-LABEL-DIV")[0].children[0].children[0].textContent;
                if (opp_string == "Tender No.") {
                    console.log("opportunity is a tender, dk if period or not")
                    if (document.getElementsByClassName("formOutputText_VALUE-DIV")[10].textContent == "Period Contract") {
                        // opportunity is a period contract
                        // 16 fields
                        let new_name_mapping = {
                            'TENDER_ID': 'Tender No.',
                            'REFERENCE_NO': 'Reference No.',
                            'AGENCY': 'Agency',
                            'PUBLISHED_DT': 'Published',
                            'OFFER_VALIDITY_DURATION': 'Offer Validity Duration',
                            'REMARKS': 'Remarks',
                            'PROCUREMENT_TYPE': 'Procurement Type',
                            'TWO_ENVELOPE_BIDDING': 'Two Envelope Bidding',
                            'QUOTATION_TENDER_TYPE': 'Tender Type',
                            'COVERED_UNDER_WTO_GPA_FTA': 'Covered under WTO-GPA/FTA',
                            'PROCUREMENT_NATURE': 'Procurement Nature',
                            'PERIOD_CONTRACT_START_DT': 'Period Contract Start Date',
                            'PERIOD_CONTRACT_END_DT': 'Period Contract End Date',
                            'PROCUREMENT_METHOD': 'Procurement Method',
                            'REQUEST_FOR_PROPOSAL': 'Request for Proposal',
                            'GRA_SUPPLY_WORK_HEADS': 'GRA Supply/Work Heads [Tendering Capacity]',
                            'PROCUREMENT_CATEGORY': 'Procurement Category',
                            'STATUS': 'Status',
                        }
                        let field_list = ["TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "OFFER_VALIDITY_DURATION", "REMARKS", "PROCUREMENT_TYPE", "TWO_ENVELOPE_BIDDING", "QUOTATION_TENDER_TYPE", "COVERED_UNDER_WTO_GPA_FTA", "PROCUREMENT_NATURE", "PERIOD_CONTRACT_START_DT", "PERIOD_CONTRACT_END_DT", "PROCUREMENT_METHOD", "REQUEST_FOR_PROPOSAL", "GRA_SUPPLY_WORK_HEADS", "PROCUREMENT_CATEGORY", "STATUS"]
                        let field_values = []
                        for (var i = 0; i < field_list.length - 1; i++) {
                            let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                            field_values.push(field_value)
                        }
                        let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                        field_values.push(status_field);

                        let field_dict = {}
                        for (var i = 0; i < field_list.length; i++) {
                            field_dict[field_list[i]] = field_values[i]
                        }

                        let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                        field_dict["TENDER_NME"] = tender_name;

                        field_dict["TYPE_OF_OPPORTUNITY"] = "Tender - Period Contract"

                        field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                        let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                        // change '04 Aug 2023' to '2023-08-04' format
                        month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }

                        let end_dt_split = end_dt.split(" ")
                        let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                        field_dict["END_DT"] = end_dt_new

                        let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                        let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                        field_dict["PUBLISHED_DT"] = published_dt_new

                        if (corrigendum_html != null) {
                            field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                        }

                        let bids = []
                        let awards = []


                        console.log(field_dict)
                        console.log(bids)
                        console.log(awards)
                        return { 0: field_dict, 1: bids, 2: awards }

                    } else { // non period contract
                        console.log("non period contract")
                        // opportunity is non period contract
                        let new_name_mapping = {
                            'TENDER_ID': 'Tender No.',
                            'REFERENCE_NO': 'Reference No.',
                            'AGENCY': 'Agency',
                            'PUBLISHED_DT': 'Published',
                            'OFFER_VALIDITY_DURATION': 'Offer Validity Duration',
                            'REMARKS': 'Remarks',
                            'PROCUREMENT_TYPE': 'Procurement Type',
                            'TWO_ENVELOPE_BIDDING': 'Two Envelope Bidding',
                            'QUOTATION_TENDER_TYPE': 'Tender Type',
                            'COVERED_UNDER_WTO_GPA_FTA': 'Covered under WTO-GPA/FTA',
                            'PROCUREMENT_NATURE': 'Procurement Nature',
                            'PROCUREMENT_METHOD': 'Procurement Method',
                            'REQUEST_FOR_PROPOSAL': 'Request for Proposal',
                            'GRA_SUPPLY_WORK_HEADS': 'GRA Supply/Work Heads [Tendering Capacity]',
                            'PROCUREMENT_CATEGORY': 'Procurement Category',
                            'STATUS': 'Status',
                        }
                        let field_list = ["TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "OFFER_VALIDITY_DURATION", "REMARKS", "PROCUREMENT_TYPE", "TWO_ENVELOPE_BIDDING", "QUOTATION_TENDER_TYPE", "COVERED_UNDER_WTO_GPA_FTA", "PROCUREMENT_NATURE", "PROCUREMENT_METHOD", "REQUEST_FOR_PROPOSAL", "GRA_SUPPLY_WORK_HEADS", "PROCUREMENT_CATEGORY", "STATUS"]
                        let field_values = []

                        for (var i = 0; i < field_list.length - 1; i++) {
                            let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                            field_values.push(field_value)
                        }
                        let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                        field_values.push(status_field);

                        let field_dict = {}
                        for (var i = 0; i < field_list.length; i++) {
                            field_dict[field_list[i]] = field_values[i]
                        }

                        let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                        field_dict["TENDER_NME"] = tender_name;

                        field_dict["TYPE_OF_OPPORTUNITY"] = "Tender - Non Period Contract"
                        field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                        let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                        // change '04 Aug 2023' to '2023-08-04' format
                        month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }

                        let end_dt_split = end_dt.split(" ")
                        let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                        field_dict["END_DT"] = end_dt_new

                        let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                        let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                        field_dict["PUBLISHED_DT"] = published_dt_new

                        if (corrigendum_html != null) {
                            field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                        }

                        let bids = []
                        let awards = []

                        return { 0: field_dict, 1: bids, 2: awards }


                    }
                    // if opp_string contains Quotation No., then it is a quotation
                } else if (opp_string.includes("Quotation No.")) {
                    // opportunity is a quotation
                    console.log("opportunity is a quotation")

                    let new_name_mapping = {
                        'TENDER_ID': 'Quotation No.',
                        'REFERENCE_NO': 'Reference No.',
                        'AGENCY': 'Agency',
                        'PUBLISHED_DT': 'Published',
                        'OFFER_VALIDITY_DURATION': 'Offer Validity Duration', // have for normal quotations...
                        'REMARKS': 'Remarks',
                        'PROCUREMENT_TYPE': 'Procurement Type',
                        'QUOTATION_TENDER_TYPE': 'Quotation Type',
                        'PROCUREMENT_NATURE': 'Procurement Nature',
                        'PROCUREMENT_METHOD': 'Procurement Method',
                        // 'PERIOD_CONTRACT_NO': 'Period Contract No.', // this one only appears in special invited
                        'PAYMENT_TERMS': 'Payment Terms',
                        'QUOTATION_BOX_NO': 'Quotation Box No.',
                        'PROCUREMENT_CATEGORY': 'Procurement Category',
                        'STATUS': 'Status',
                    }
                    let field_list = ["TENDER_ID", "REFERENCE_NO", "AGENCY", "PUBLISHED_DT", "OFFER_VALIDITY_DURATION", "REMARKS", "PROCUREMENT_TYPE", "QUOTATION_TENDER_TYPE", "PROCUREMENT_NATURE", "PROCUREMENT_METHOD", "PAYMENT_TERMS", "QUOTATION_BOX_NO", "PROCUREMENT_CATEGORY", "STATUS"]

                    // if got Period Contract No., then remove Offer Validity Duration, and then add Period Contract No. to field_list after PROCUREMENT_METHOD
                    if (document.getElementsByClassName("form2_ROW-LABEL-DIV")[9].getElementsByTagName("span")[0].textContent == "Period Contract No.") {
                        field_list.splice(4, 1)
                        field_list.splice(9, 0, "PERIOD_CONTRACT_NO")
                    }

                    let field_values = [];
                    for (var i = 0; i < field_list.length - 1; i++) {
                        console.log(i);
                        let field_value = document.getElementsByClassName("formOutputText_VALUE-DIV")[i].textContent
                        field_values.push(field_value)
                    }
                    let status_field = document.getElementsByClassName("label_MAIN")[0].textContent;
                    field_values.push(status_field);

                    let field_dict = {}
                    for (var i = 0; i < field_list.length; i++) {
                        field_dict[field_list[i]] = field_values[i]
                    }

                    let tender_name = document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                    field_dict["TENDER_NME"] = tender_name;

                    field_dict["TYPE_OF_OPPORTUNITY"] = "Quotation"
                    field_dict["CREATED_DT"] = new Date().toISOString().slice(0, 10);

                    let end_dt = document.getElementsByClassName("outputText_NAME-BLACK")[0].innerText.split("\n")[0]

                    // change '04 Aug 2023' to '2023-08-04' format
                    month_mapping = {
                        "Jan": "01",
                        "Feb": "02",
                        "Mar": "03",
                        "Apr": "04",
                        "May": "05",
                        "Jun": "06",
                        "Jul": "07",
                        "Aug": "08",
                        "Sep": "09",
                        "Oct": "10",
                        "Nov": "11",
                        "Dec": "12"
                    }

                    let end_dt_split = end_dt.split(" ")
                    let end_dt_new = end_dt_split[2] + "-" + month_mapping[end_dt_split[1]] + "-" + end_dt_split[0]
                    field_dict["END_DT"] = end_dt_new

                    let published_dt_split = field_dict["PUBLISHED_DT"].split(" ")
                    let published_dt_new = published_dt_split[2] + "-" + month_mapping[published_dt_split[1]] + "-" + published_dt_split[0]
                    field_dict["PUBLISHED_DT"] = published_dt_new

                    if (corrigendum_html != null) {
                        field_dict["CORRIGENDUM_HTML_TEXT"] = corrigendum_html;
                    }

                    let bids = []
                    let awards = []

                    // if got Period Contract No., then delete it from field_dict and append it behind tender_name
                    if (field_dict.hasOwnProperty("PERIOD_CONTRACT_NO")) {
                        let period_contract_no = field_dict["PERIOD_CONTRACT_NO"]
                        delete field_dict["PERIOD_CONTRACT_NO"]
                        field_dict["TENDER_NME"] = field_dict["TENDER_NME"] + " - Period Contract Number: " + period_contract_no
                    }


                    return { 0: field_dict, 1: bids, 2: awards };
                }

                console.log("returning here")
                return

            }
        }, async function (result) {

            if (result[0].result == null) {
                statusdiv.textContent = "5: no info extracted, going to try again...\n\n";
                return
            }

            async function sleep(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }

            statusdiv.textContent = "5: Extracted information from page\n\n";
            console.log(result);
            let request_dict = result[0].result[0];

            document.getElementById("idholder").textContent = request_dict["TENDER_ID"];
            // get file name from download path, example: "C:\\Users\\adam.ho\\Downloads\\CPF000ERQ23000023 (3).zip"
            // let file_name = download_path.split("\\").pop().split(" (")[0];

            let download_path = document.getElementById("multidownloadholder").textContent.slice(0, -1);
            let quotation_doc_paths = [];
            // for each path in download_path, get file name and append to QUOTATION_DOC_PATH
            download_path.split(";").forEach(function (path) {
                quotation_doc_paths.push(path.split("\\").pop());
            });
            let quotation_doc_path_string = "";
            quotation_doc_paths.forEach(function (path) {
                quotation_doc_path_string += path + ";";
            });
            quotation_doc_path_string = quotation_doc_path_string.slice(0, -1);
            request_dict["QUOTATION_DOC_PATH"] = quotation_doc_path_string;

            let corrigendum_doc_paths = [];
            let corri_download_path = document.getElementById("corrigendumholder").textContent.slice(0, -1);
            corri_download_path.split(";").forEach(function (path) {
                corrigendum_doc_paths.push(path.split("\\").pop());
            });
            let corrigendum_doc_path_string = "";
            corrigendum_doc_paths.forEach(function (path) {
                corrigendum_doc_path_string += path + ";";
            });
            corrigendum_doc_path_string = corrigendum_doc_path_string.slice(0, -1);
            request_dict["CORRIGENDUM_DOC_PATH"] = corrigendum_doc_path_string;

            console.log(request_dict);
            // maybe send to server the html here
            await sleep(300);
            console.log("sending request_dict to server");

            // TODO
            // send request_dict to server here
            await fetch(`${backendURL}/opportunity`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "5.a: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );
        });
    });

}

async function bidsOwnActivity() { // wait for download all

    statusdiv.textContent = "4,o,0: checking if need to go to View Submitted Response"
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                console.log("View Submitted Response activity here")
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                if (document.getElementsByClassName("formTabBar_TAB-BUTTON").length == 0 || !document.getElementsByClassName("formTabBar_TAB-BUTTON")[0].value.includes("Respondent")) {
                    // iterate thru classes "document.getElementsByClassName("commandLink_MAIN")"
                    let buttons = document.getElementsByClassName("commandLink_MAIN");
                    for (let i = 0; i < buttons.length; i++) {
                        if (buttons[i].textContent.includes("View Submitted Response")) {
                            buttons[i].click();
                            return 1
                        }
                    }
                    
                }

                
                return -1
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4,o,-1: No need to go to View Submitted Response"
                    return
                } else if (result[0].result == 1) {
                    statusdiv.textContent = "4,o,1: go to View Submitted Response"
                    return

                } else if (result[0].result == null) {
                    statusdiv.textContent = "4,o,1: go to View Submitted Response"
                    return
                }
            }
            catch {
                // pass
                statusdiv.textContent = "4,o,1: go to View Submitted Response"
                return
            }
            statusdiv.textContent = "4,o,1: go to View Submitted Response"

        });
    });

}

async function bidsOwnActivity1() { // wait for download all

    statusdiv.textContent = "4,o,2: checking if view submitted response page loaded"
    
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // if tab is still loading, return false
        if (tabs[0].status == "loading") {
            statusdiv.textContent = "4,o,l: page is still loading..."
            return;
        }

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                if (document.getElementsByClassName("design-02_rui-layout_default_CONTENT-TITLE").length == 0) {
                    return -1
                }

                if (document.getElementsByClassName("design-02_rui-layout_default_CONTENT-TITLE")[0].textContent.includes("Your Submitted Response")) {
                    return 1
                }

                return -1
                
            }
        }, function (result) {

            try {
                if (result[0].result == -1) {

                    statusdiv.textContent = "4,o,l: view submitted response is still loading..."
                    return
                } else if (result[0].result == 1) {
                    statusdiv.textContent = "4,o,3: view submitted response page loaded"
                    return

                } else if (result[0].result == null) {
                    statusdiv.textContent = "4,o,l: view submitted response is still loading..."
                    return
                }
            }
            catch {
                // pass
                statusdiv.textContent = "4,o,l: view submitted response is still loading..."
                return
            }
            statusdiv.textContent = "4,o,l: view submitted response is still loading..."

        });
    });

}

async function bidsOwnActivity2() { // wait for download all

    statusdiv.textContent = "4,o,4: extracting view submitted response page"

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let opportunity_id = document.getElementsByClassName("outputText_LABEL-GRAY")[0].textContent.split("-")[1].trim()
                let vendor_nme = "ACCENTURE SG SERVICES PTE. LTD."
                for (let a = 0; a < document.getElementsByTagName("span").length; a++) {
                    if (document.getElementsByTagName("span")[a].textContent.includes("Supplier Name")) {
                        vendor_nme = document.getElementsByTagName("span")[a].parentElement.parentElement.parentElement.parentElement.parentElement.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent
                    }
                }

                if (vendor_nme == null || vendor_nme == undefined) {
                    vendor_nme = "ACCENTURE SG SERVICES PTE. LTD."
                }

                // if have Expand All, click it
                if (document.getElementsByClassName("formAccordionGroup_EXPAND-All-DIV").length > 0) {
                    document.getElementsByClassName("formAccordionGroup_EXPAND-All-DIV")[0].click();
                    await sleep(500);
                }

                let bids = []

                // iterate through document.getElementsByClassName("formAccordion_TITLE-TEXT")
                for (let i = 0; i < document.getElementsByClassName("formAccordion_TITLE-TEXT").length; i++) {
                    let item_nme = document.getElementsByClassName("formAccordion_TITLE-TEXT")[i].innerHTML.split("</span>")[1]
                    let bid_amt = document.getElementsByClassName("formAccordion_TITLE-BAR")[i].textContent
                    bid_amt = bid_amt.replaceAll(/\([^()]*\)/g, '');
                    bid_amt = bid_amt.replaceAll(",", '');
                    bid_amt = bid_amt.trim();

                    let bid_dict = {
                        "TENDER_ID" : opportunity_id,
                        "VENDOR_NME": vendor_nme,
                        "ITEM_NME": item_nme,
                        "BID_AMT": bid_amt
                    }

                    bids.push(bid_dict)

                }

                return bids
                
            }
        }, function (result) {

            try {
                if (result[0].result == null) {
                    statusdiv.textContent = "4,o,-4: error extracting view submitted response page"
                    return
                }
            }
            catch {
                // pass
                statusdiv.textContent = "4,o,-4: error extracting view submitted response page"
                return
            }

            let request_dict = result[0].result;

            fetch(`${backendURL}/bid`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "4,o,5: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );
            

        });
    });

}

async function exitVSR() { // exit view submitted response page

    statusdiv.textContent = "4,o,6: exiting view submitted response page"

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                
                // write functions here that will be injected to current tab, await to run in order
                // click into download all button
                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                for (let i = 0; i < document.getElementsByClassName("commandButton_BIG-DARK-GRAY").length; i++) {
                    if (document.getElementsByClassName("commandButton_BIG-DARK-GRAY")[i].value.includes("Exit")) {
                        document.getElementsByClassName("commandButton_BIG-DARK-GRAY")[i].click();
                    }
                }
                
            }
        }, function (result) {

            statusdiv.textContent = "4,o,7: clicked exit view submitted response page"
            

        });
    });

}


async function five0Activity() { // click into bids and awards
    statusdiv.textContent = "5,0ip: clicking into bids and awards tab if have"
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into bids and awards
                if (document.getElementsByClassName("formTabBar_TAB-BUTTON").length > 0) {
                    console.log("got bids and awards tab button")
                    // got bids / awards
                    if (document.getElementsByClassName("formTabBar_TAB-BUTTON")[0].value.slice(0, 10) == "Respondent") {
                        // got respondents
                        document.getElementsByClassName("formTabBar_TAB-BUTTON")[0].click()
                        return 1;

                    }

                    if (document.getElementsByClassName("formTabBar_TAB-BUTTON")[0].value.slice(0, 5) == "Award") {
                        // got awards
                        document.getElementsByClassName("formTabBar_TAB-BUTTON")[0].click()
                        return 2;

                    }

                    if (document.getElementsByClassName("formTabBar_TAB-BUTTON")[1].value.slice(0, 5) == "Award") {
                        // got awards
                        document.getElementsByClassName("formTabBar_TAB-BUTTON")[1].click()
                        return 3;

                    }
                    return 0;

                }

                return 9;
            }
        }, async function (result) {
            if (result[0].result == 0) {
                statusdiv.textContent = "5.3: no bids or awards";
                return;
            }
            statusdiv.textContent = "5.0: " + result[0].result;

        })
    });
}


async function five1Activity() { // executed if got bids
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order

                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let bids = [];

                // extract bids
                // click "Expand All"
                console.log("clicking expand all")

                // while loading...
                while (document.getElementsByClassName("formTabBar_TAB-BUTTON-ACTIVE")[0].value.slice(0, 10) != "Respondent") {
                    await sleep(300);
                    continue;
                }

                if (document.getElementsByClassName("formAccordionGroup_EXPAND-All-DIV").length == 0) {
                    let bids = [];
                    // no expand all button, just save company names as it is request for information
                    // getting how many responded first
                    let numberOfRespondents = parseInt(document.getElementsByClassName("formRow_HIDDEN-LABEL")[1].textContent.split(" ")[0]);

                    for (let i = 2; i < numberOfRespondents + 2; i++) {
                        let vendor_nme = document.getElementsByClassName("formRow_HIDDEN-LABEL")[i].textContent

                        let bid_dict = {
                            "VENDOR_NME": vendor_nme,
                            "ITEM_NME": "Request for Information",
                            "BID_AMT": "0"
                        }

                        bids.push(bid_dict)
                    }
                    console.log(bids)
                    return bids;
                }

                document.getElementsByClassName("formAccordionGroup_EXPAND-All-DIV")[0].click()
                console.log("clicked expand all")
                console.log("before iterating through bids")


                let numberOfBidders = document.getElementsByClassName("formAccordion_BAR").length;
                console.log("gonna iterate through bids now")
                console.log("number of bidders is " + numberOfBidders)
                for (let i = 0; i < numberOfBidders; i++) {
                    console.log("i is " + i)
                    let vendor_nme = document.getElementsByClassName("formAccordion_BAR")[i].children[1].children[1].textContent
                    let no_of_items_in_this_bid = parseInt(document.getElementsByClassName("formAccordion_BAR")[i].getElementsByClassName("formColumns_MAIN").length)
                    console.log("no of items in this bid is " + no_of_items_in_this_bid)

                    for (let j = 0; j < no_of_items_in_this_bid; j++) {
                        console.log("j is " + j)
                        let item_nme = null;
                        let bid_amt = null;
                        try {
                            item_nme = document.getElementsByClassName("formAccordion_BAR")[i].getElementsByClassName("formColumns_MAIN")[j].getElementsByClassName("outputText_TITLE-BLACK")[0].textContent;
                            bid_amt = document.getElementsByClassName("formAccordion_BAR")[i].getElementsByClassName("formColumns_MAIN")[j].getElementsByClassName("table_TABLE-CELL-TD")[4].textContent;
                        } catch {
                            continue
                        }

                        bid_amt = bid_amt.replaceAll(/\([^()]*\)/g, '');
                        bid_amt = bid_amt.replaceAll(",", '');
                        bid_amt = bid_amt.trim();


                        let bid_dict = {
                            "VENDOR_NME": vendor_nme,
                            "ITEM_NME": item_nme,
                            "BID_AMT": bid_amt
                        }

                        bids.push(bid_dict)
                        console.log("pushed bid dict:" + JSON.stringify(bid_dict));

                    }

                }
                console.log("returning bids here:")
                console.log(bids)
                return bids;
            }
        }, function (result) {

            // if null, need to call again
            if (result[0].result == null) {
                statusdiv.textContent = "5a-1: exited early, no bids";
                return;
            }

            console.log("bids here:" + JSON.stringify(result[0].result))

            statusdiv.textContent = "5.1: extracted bids";

            let request_dict = result[0].result;

            // iterate through request dict and add tender id to each award
            for (var i = 0; i < request_dict.length; i++) {
                request_dict[i]["TENDER_ID"] = document.getElementById("idholder").textContent;
            }

            // TODO
            // send request_dict to server here
            fetch(`${backendURL}/bid`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "5.1a: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );

        })
    }
    );


}

async function five2Activity() { // executed if got awards
    statusdiv.textContent = "5a2: extracting awards";
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order

                async function sleep(ms) {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }

                let awards = []

                while (document.getElementsByClassName("formTabBar_TAB-BUTTON-ACTIVE")[0].value.slice(0, 5) != "Award") {
                    await sleep(300);
                    continue;
                }

                if (document.getElementsByClassName("formTabBar_TAB-BUTTON-ACTIVE")[0].value == "Award (0)") {
                    return [];
                }

                // if only awarded suppliers can see the award details...
                try {
                    if (document.getElementsByClassName("formRow_HIDDEN-LABEL")[0].getElementsByTagName("span")[0].textContent == "Only awarded suppliers can view the award details.") {
                        let awarded_company = "Unknown"
                        let awarded_amt = document.getElementsByClassName("formOutputText_VALUE-DIV")[3].textContent;
                        let awarded_dt = document.getElementsByClassName("formOutputText_VALUE-DIV")[2].textContent;

                        let month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }

                        let awarded_dt_split = awarded_dt.split(" ")
                        let awarded_dt_new = awarded_dt_split[2] + "-" + month_mapping[awarded_dt_split[1]] + "-" + awarded_dt_split[0]

                        awarded_amt = awarded_amt.replaceAll(/\([^()]*\)/g, '');
                        // remove all ","
                        awarded_amt = awarded_amt.replaceAll(",", '');
                        awarded_amt = awarded_amt.trim();



                        let award_dict = {
                            "AWARDED_COMPANY": awarded_company,
                            "AWARDED_AMT": awarded_amt,
                            "AWARDED_DT": awarded_dt_new
                        }

                        awards.push(award_dict)
                        return awards;


                    }
                    
                    
                }
                catch {

                }

                // extract awards
                let numberOfAwards = 1;
                try {
                    numberOfAwards = parseInt(document.getElementsByClassName("formOutputText_VALUE-DIV")[0].textContent);
                } catch {
                    
                }

                if (numberOfAwards == 1) {
                    for (let i = 0; i < numberOfAwards; i++) {
                        let awarded_company = document.getElementsByClassName("outputText_TITLE-BLACK")[2].textContent;
                        let awarded_amt = document.getElementsByClassName("formOutputText_VALUE-DIV")[3].textContent;
                        let awarded_dt = document.getElementsByClassName("formOutputText_VALUE-DIV")[2].textContent;
    
                        let month_mapping = {
                            "Jan": "01",
                            "Feb": "02",
                            "Mar": "03",
                            "Apr": "04",
                            "May": "05",
                            "Jun": "06",
                            "Jul": "07",
                            "Aug": "08",
                            "Sep": "09",
                            "Oct": "10",
                            "Nov": "11",
                            "Dec": "12"
                        }
    
    
                        awarded_amt = awarded_amt.replaceAll(/\([^()]*\)/g, '');
                        awarded_amt = awarded_amt.replaceAll(",", '');
                        awarded_amt = awarded_amt.trim();
    
    
                        let awarded_dt_split = awarded_dt.split(" ")
                        let awarded_dt_new = awarded_dt_split[2] + "-" + month_mapping[awarded_dt_split[1]] + "-" + awarded_dt_split[0]
    
                        let award_dict = {
                            "AWARDED_COMPANY": awarded_company,
                            "AWARDED_AMT": awarded_amt,
                            "AWARDED_DT": awarded_dt_new
                        }
    
                        awards.push(award_dict)
    
    
    
                    }
                    return awards;
                }
                
                for (let i = 0; i < numberOfAwards; i++) {
                    let awarded_company = document.getElementsByClassName("formRepeat_MAIN")[0].getElementsByClassName("formOutputText_HIDDEN-LABEL outputText_TITLE-BLACK")[i*3].textContent;
                    let awarded_amt = document.getElementsByClassName("formRepeat_MAIN")[0].getElementsByClassName("formOutputText_HIDDEN-LABEL outputText_TITLE-BLACK")[i*3].parentElement.parentElement.parentElement.parentElement.parentElement.nextSibling.nextSibling.getElementsByClassName("formOutputText_VALUE-DIV ")[0].textContent;
                    let awarded_dt = document.getElementsByClassName("formOutputText_VALUE-DIV")[2].textContent;

                    let month_mapping = {
                        "Jan": "01",
                        "Feb": "02",
                        "Mar": "03",
                        "Apr": "04",
                        "May": "05",
                        "Jun": "06",
                        "Jul": "07",
                        "Aug": "08",
                        "Sep": "09",
                        "Oct": "10",
                        "Nov": "11",
                        "Dec": "12"
                    }


                    awarded_amt = awarded_amt.replaceAll(/\([^()]*\)/g, '');
                    awarded_amt = awarded_amt.replaceAll(",", '');
                    awarded_amt = awarded_amt.trim();


                    let awarded_dt_split = awarded_dt.split(" ")
                    let awarded_dt_new = awarded_dt_split[2] + "-" + month_mapping[awarded_dt_split[1]] + "-" + awarded_dt_split[0]

                    let award_dict = {
                        "AWARDED_COMPANY": awarded_company,
                        "AWARDED_AMT": awarded_amt,
                        "AWARDED_DT": awarded_dt_new
                    }

                    awards.push(award_dict)



                }
                return awards;
            }
        }, async function (result) {

            // if null, need to call again
            if (result[0].result == null) {
                statusdiv.textContent = "5a-2: exited early, no awards";
                return;
            }

            console.log("awards here:" + JSON.stringify(result[0].result))
            statusdiv.textContent = "5.2: extracted awards";

            let request_dict = result[0].result;

            // iterate through request dict and add tender id to each award
            for (var i = 0; i < request_dict.length; i++) {
                request_dict[i]["TENDER_ID"] = document.getElementById("idholder").textContent;
            }


            // TODO
            // send request_dict to server here
            fetch(`${backendURL}/award`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + loginToken,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request_dict),
            })
                .then(data => {
                    console.log('Success:', data);
                    // if success returned...
                    if (data.status == 200 || data.status == 201) {
                        statusdiv.textContent = "5.2a: " + data;
                    } else {
                        statusdiv.textContent = "5.2: Server may be down: \n" + error;
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                    statusdiv.textContent = "5.2: Server may be down: \n" + error;
                }
                );

        })
    }
    );


}

async function sixthActivity() { // click back to invitations
    // go into current tab
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into opportunities
                // click the 3rd breadcrumb link
                // document.getElementsByClassName("breadcrumb_LINK")[2].click();

                fetch("http://localhost:5001/resetcorricounter");


                document.getElementsByClassName("commandButton_BACK-BLUE-TEXT")[0].click(); // click back to search results (dynamic)

                return true;
            }
        }, async function (result) {
            statusdiv.textContent = "6,0: clicked back to search results";
            document.getElementById("multidownloadholder").textContent = "";
            document.getElementById("lastdownloadholder1").textContent = "";
            document.getElementById("corrigendumholder").textContent = "";
            document.getElementById("idholder").textContent = "";
            fetch("http://localhost:5001/resetcorricounter");

        })
    });
}

async function checkPostSixActivity() {

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

        // inject script into current tab
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            function: async () => {
                // write functions here that will be injected to current tab, await to run in order
                // click into opportunities
                // click the 3rd breadcrumb link
                // document.getElementsByClassName("breadcrumb_LINK")[2].click();

                return document.getElementsByClassName("outputText_TITLE-BLACK")[0].textContent.includes("results found");
            }
        }, async function (result) {

            if (result[0].result) {
                statusdiv.textContent = "6:invited page loaded";
            }

        })
    });
}

async function getOneOpportunity() {

    function checkTimeout() {
        return statusdiv.textContent == "timed out";
    }

    async function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    let counter0;
    let paused1 = true;
    counter0 = fetch('http://localhost:5001/checkcounter')
        .then(function (response) {
            if (response.ok) {
                return response.text();
            }
            throw new Error('Network response was not ok.');
        })
        .then(function (data) {
            // data is the counter
            paused1 = false;
            counter0 = data;
            return data;
        }
        );

    while (paused1) {
        await sleep(300);
        console.log("paused1 as waiting for counter")
        continue;
    }

    await preFirstActivity(); // check if correct page

    while (statusdiv.textContent.slice(0, 4) != "0,0:") { // while not correct page
        if (checkTimeout()) {
            return false;
        }

        if (statusdiv.textContent.slice(0, 5) == "0,-1:") { // waiting the check
            await sleep(300);
            continue
        }

        if (statusdiv.textContent.slice(0, 6) == "0,0,0:") {
            await sleep(300);
            continue
        }

        if (statusdiv.textContent.slice(0, 5) == "0,-1:") {
            await sleep(300);
            continue;
        }


        if (statusdiv.textContent.slice(0, 4) == "0,1:") { // need to click next page
            await clickNextOpportunityPage();
            await sleep(300);
            continue
        }

        await preFirstActivity();
        await sleep(300);

    }


    await firstActivity(); // works



    chrome.tabs.onUpdated.addListener(async function (tabId, changeInfo, tab) { // wait for opportunity page to load
        
        async function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
        
        if (changeInfo.status == 'complete' && tab.active) {
            await sleep(300);
            statusdiv.textContent = "1:page loaded, finding download all button...";
            // remove listener
            chrome.tabs.onUpdated.removeListener(arguments.callee);
        }
    })

    while (statusdiv.textContent.slice(0, 2) != "1:") { // wait for opportunity page to load
        if (checkTimeout()) {
            return false;
        }
        console.log("first activity not complete")
        await sleep(300);
    }

    if (statusdiv.textContent == "1:false") { // if all the opportunities in the page are already in the databse, means completed.
        return false;
    }

    await checkSpecial();

    while (statusdiv.textContent.slice(0, 6) == "1.8.0:" || statusdiv.textContent.slice(0,5) == "1,-8:") {
        if (checkTimeout()) {
            return false;
        }

        if (statusdiv.textContent.slice(0,5) == "1,-8:") {
            await checkSpecial();
            await sleep(300);
            continue;
        }

        console.log("check special not complete")

        await sleep(300);
    }


    if (statusdiv.textContent.slice(0, 4) == "1.8:") {
        await sleep(300);
        await second0Activity();

        while (statusdiv.textContent.slice(0, 3) != "1.9") { // wait for 1.0
            if (checkTimeout()) {
                return false;
            }
            console.log("2.0 activity not complete")
            await sleep(300);
        }

        await secondActivity();

        while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
            if (checkTimeout()) {
                return false;
            }
            console.log("second activity not complete")

            if (statusdiv.textContent.slice(0, 5) == "2,-1:") {
                break;
            }

            await sleep(300);

            // TODO
            // implement self-fixing to download button spoiling here if timer hits 20s?
            // click the first document button with this element:
            // document.getElementsByClassName("formColumns_COLUMN-TD")[2].getElementsByTagName("a")[0]
        }

        if (statusdiv.textContent.slice(0, 5) != "2,-1:") { //if got download button, then download sequence

            await thirdActivity();

            while (statusdiv.textContent.slice(0, 2) != "3:") { // wait for third activity to complete, third activity needs to be recalled to check if download is complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("third activity not complete")

                if (statusdiv.textContent == "2 : Waiting for download to start... (download button may be spoilt if it is taking long)" && parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                    await fixsecondActivity();
                    await sleep(300);
                    await secondActivity();
                    await sleep(300);

                    while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("second activity not complete")
                        await sleep(300);

                    }

                    continue

                }



                await thirdActivity();
                await sleep(300);
            }
            await sleep(300);
            await fourthActivity();

            while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("fourth activity not complete")

                if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                    await fourthActivity();
                }

                await sleep(300);
            }

            await fourth1Activity();

            while (statusdiv.textContent.slice(0, 3) != "4.2") { // wait for fourth activity to complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("fourth 1 activity not complete")

                if (statusdiv.textContent.slice(0, 4) == "4.-1") { // try to call again because loading
                    await fourth1Activity();
                }

                else if (statusdiv.textContent.slice(0, 3) == "4.1") {

                    await second0Activity();

                    while (statusdiv.textContent.slice(0, 3) != "1.9") { // wait for 1.0
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("2.0 activity not complete")
                        await sleep(300);
                    }


                    await secondActivity();

                    while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("second activity not complete")
                        await sleep(300);

                        // TODO
                        // implement self-fixing to download button spoiling here if timer hits 20s?
                        // click the first document button with this element:
                        // document.getElementsByClassName("formColumns_COLUMN-TD")[2].getElementsByTagName("a")[0]
                    }

                    await thirdActivity();

                    while (statusdiv.textContent.slice(0, 2) != "3:") { // wait for third activity to complete, third activity needs to be recalled to check if download is complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("third activity not complete")

                        if (statusdiv.textContent == "2 : Waiting for download to start... (download button may be spoilt if it is taking long)" && parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                            await fixsecondActivity();
                            await sleep(300);
                            await secondActivity();
                            await sleep(300);

                            while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                                if (checkTimeout()) {
                                    return false;
                                }
                                console.log("second activity not complete")
                                await sleep(300);

                            }

                            continue
                        }

                        await thirdActivity();
                        await sleep(300);
                    }
                    await sleep(300);
                    await fourthActivity();

                    while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("fourth activity not complete")

                        if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                            await fourthActivity();
                        }

                        await sleep(300);
                    }

                    await fourth1Activity();

                }

                await sleep(300);
            }
        }

        await sleep(300);

        await corrigendumActivity();

        while (statusdiv.textContent.slice(0, 6) == "4,4,1:") { // wait for fourth activity to complete
            if (checkTimeout()) {
                return false;
            }
            console.log("corrigendum activity not complete")
            await sleep(300);
        }

        if (statusdiv.textContent.slice(0, 7) == "4,4,-1:") { // no need to do corrigendum activity

        } else {
            let numberOfCorrigendumButton = parseInt(document.getElementById("corrigendumcount").textContent);
            for (let i = 0; i < numberOfCorrigendumButton; i++) {
                await sleep(300);
                await corrigendum1Activity();

                while (statusdiv.textContent.slice(0, 6) == "4,6,1:") { // wait for fourth activity to complete
                    if (checkTimeout()) {
                        return false;
                    }
                    console.log("corrigendum 1 activity not complete")
                    await sleep(300);
                }

                await corrigendum2Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,7,1:") {
                    if (checkTimeout()) {
                        return false;
                    }
                    if (statusdiv.textContent.slice(0, 6) == "4,7,0:") { // wait for fourth activity to complete

                        console.log("corrigendum 2 activity not complete")
                        await sleep(300);
                        continue
                    }
                    if (statusdiv.textContent.slice(0, 7) == "4,7,-1:") { // need to call again
                        await sleep(300);
                        if (parseInt(document.getElementById("timerforstatus").textContent) >= 15) {
                            fetch("http://localhost:5001/decrementcorricounter");
                            await sleep(300);
                            await corrigendum1Activity();

                            while (statusdiv.textContent.slice(0, 6) == "4,6,1:") { // wait for fourth activity to complete
                                if (checkTimeout()) {
                                    return false;
                                }
                                console.log("corrigendum 1 activity not complete")
                                await sleep(300);
                            }
                            await corrigendum2Activity();
                            continue
                        }
                        await corrigendum2Activity();
                        continue
                    }
                    await sleep(300);
                }

                await corrigendum3Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,8,2:") {
                    console.log("waiting for corri 3 activity here")
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 7) == "4,8,-1:") { // activity exited, call again
                        await sleep(300);
                        await corrigendum3Activity();
                        continue
                    }

                    await sleep(300);
                }

                await corrigendum4Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,9,3:") {
                    console.log("waiting for corri 4 here")
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,0:") { // wait for fourth activity to complete
                        console.log("corrigendum 4 activity not complete")
                        await sleep(300);
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,1:" || statusdiv.textContent.slice(0, 5) == "4,8,2") { // wait for fourth activity to complete
                        console.log("corrigendum 4 activity not complete 2")
                        if (parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                            await fixcorrigendum3Activity();

                            while (statusdiv.textContent.slice(0, 8) != "4,8,9,1:") {
                                console.log("waiting for fix corri 3 activity here")
                                if (checkTimeout()) {
                                    return false;
                                }
                                await sleep(300);
                            }

                            await sleep(300);
                            await corrigendum3Activity();
                            await sleep(300);
                            continue;
                        }
                        // await fixcorrigendum3Activity();
                        await sleep(300);
                        await corrigendum4Activity();
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,2:") { // wait for fourth activity to complete
                        await corrigendum4Activity();
                        await sleep(300);
                        continue;
                    }

                    await sleep(300);

                }

                // send corrigendum folder back

                await fourthActivity();

                while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                    if (checkTimeout()) {
                        return false;
                    }
                    console.log("fourth activity not complete")

                    if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                        await fourthActivity();
                    }

                    await sleep(300);
                }

                await corrigendum5Activity();

                while (statusdiv.textContent.slice(0, 7) != "4,10,1:") {
                    if (checkTimeout()) {
                        return false;
                    }
                    await sleep(300);
                }

                await corrigendum6Activity();

                while (statusdiv.textContent.slice(0, 7) != "4,11,1:") {
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 7) == "4,11,0:") { // wait for fourth activity to complete
                        console.log("corrigendum 6 activity not complete")
                        await sleep(300);
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 8) == "4,11,-1:") { // not back, call again
                        await corrigendum6Activity();
                        await sleep(300);
                        continue;
                    }

                    await sleep(300);

                }

            }
        }



        await fifthActivity();

        while (statusdiv.textContent.slice(0, 4) != "5.a:") { // wait for fifth activity to complete
            if (checkTimeout()) {
                return false;
            }

            if (statusdiv.textContent.slice(0, 3) == "5s:") { // wait for fifth activity to complete
                await sleep(300);
                continue;
            }

            if (parseInt(document.getElementById("timerforstatus").textContent) >= 10 && statusdiv.textContent.slice(0, 2) == "5:") {
                await fifthActivity();
                await sleep(300);
                continue;
            }

            console.log("fifth activity not complete")
            await sleep(300);
        }

        await bidsOwnActivity();

        while (!(statusdiv.textContent.slice(0, 6) == "4,o,1:" || statusdiv.textContent.slice(0,7) == "4,o,-1:")) { 
            
            if (checkTimeout()) {
                return false;
            }

            if (statusdiv.textContent.slice(0, 6) == "4,o,0:") {
                await sleep(300);
                continue;
            }

            await bidsOwnActivity();
            await sleep(300);
        }

        if (statusdiv.textContent.slice(0, 6) == "4,o,1:") {
            await sleep(300);
            await bidsOwnActivity1();

            while (statusdiv.textContent.slice(0, 6) != "4,o,3:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,2:") {
                    await sleep(300);
                    continue;
                }

                await bidsOwnActivity1();
                await sleep(300);
            }

            await sleep(300);

            await bidsOwnActivity2();

            while (statusdiv.textContent.slice(0, 6) != "4,o,5:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,4:") {
                    await sleep(300);
                    continue;
                }

                await bidsOwnActivity2();
                await sleep(300);
            }

            await sleep(300);

            await exitVSR();
            
            while (statusdiv.textContent.slice(0, 6) != "4,o,7:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,6:") {
                    await sleep(300);
                    continue;
                }

                await exitVSR();
                await sleep(300);
            }

            await corrigendum6Activity();

            while (statusdiv.textContent.slice(0, 7) != "4,11,1:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 7) == "4,11,0:") { // wait for fourth activity to complete
                    console.log("corrigendum 6 activity not complete")
                    await sleep(300);
                    continue;
                }

                if (statusdiv.textContent.slice(0, 8) == "4,11,-1:") { // not back, call again
                    await corrigendum6Activity();
                    await sleep(300);
                    continue;
                }

                await sleep(300);

            }


        }

        await five0Activity();

        while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
            if (checkTimeout()) {
                return false;
            }
            if (statusdiv.textContent.slice(0, 3) == "5.3") {
                break;
            }
            if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                await sleep(300);
                continue;
            }
            await five0Activity();
            console.log("5.0 activity not complete")
            await sleep(300);
        }

        await sleep(100);

        if (statusdiv.textContent.slice(-1) == "3") {
            await five2Activity();

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

            await five0Activity();

            while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
                if (checkTimeout()) {
                    return false;
                }
                if (statusdiv.textContent.slice(0, 3) == "5.3") {
                    break;
                }
                if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                    await sleep(300);
                    continue;
                }
                await five0Activity();
                console.log("5.0 activity not complete")
                await sleep(300);
            }
        }



        if (statusdiv.textContent.slice(-1) == "1") {
            await sleep(300);
            await five1Activity();

            while (statusdiv.textContent.slice(0, 5) != "5.1a:") { // wait for 5.1
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 5) == "5a-1:") { // need to call again
                    await five1Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.1a activity not complete")
                await sleep(300);
            }

            console.log(statusdiv.textContent)
            console.log("calling five 0")
            await five0Activity();

            while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
                if (checkTimeout()) {
                    return false;
                }
                if (statusdiv.textContent.slice(0, 3) == "5.3") {
                    break;
                }
                if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                    await sleep(300);
                    continue;
                }
                await five0Activity();
                console.log("5.0 activity not complete")
                await sleep(300);
            }

        }





        if (statusdiv.textContent.slice(-1) == "2") {
            await five2Activity();
            await sleep(300);

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

        }

        if (statusdiv.textContent.slice(-1) == "3") {
            await five2Activity();
            await sleep(300);

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

        }

    } else {
        // special case, awards page is first page
        await five2SpecialActivity();

        while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
            if (checkTimeout()) {
                return false;
            }


            console.log("5.2a activity not complete")
            await sleep(300);
        }

    }
    await sleep(300);

    let lastcounter;
    let paused = true;
    lastcounter = fetch('http://localhost:5001/getcounterstatic')
        .then(function (response) {
            if (response.ok) {
                return response.text();
            }
            throw new Error('Network response was not ok.');
        })
        .then(function (data) {
            // data is the counter
            paused = false;
            lastcounter = data;
            return data;
        }
        );

    while (paused) {
        await sleep(300);
        console.log("paused as waiting for lastcounter")
        continue;
    }

    document.getElementById("lastIndexCounter").textContent = lastcounter;


    await sixthActivity();

    chrome.tabs.onUpdated.addListener(async function (tabId, changeInfo, tab) { // wait for opportunities page to load
        if (changeInfo.status == 'complete' && tab.active) {
            statusdiv.textContent = "6:invited page loaded";
            // remove listener
            chrome.tabs.onUpdated.removeListener(arguments.callee);
        }
    })

    while (statusdiv.textContent.slice(0, 2) != "6:") {
        if (checkTimeout()) {
            return false;
        }

        if (document.getElementById("timerforstatus").textContent >= 20) {
            await sixthActivity();
            await sleep(300);
            continue
        }

        await checkPostSixActivity();



        console.log("home page not complete")
        await sleep(300);
    }

    document.getElementById("numberCompleted").innerText = parseInt(document.getElementById("numberCompleted").innerText) + 1;

    return true;

}

async function getOnlyOneOpportunity() {

    function checkTimeout() {
        return statusdiv.textContent == "timed out";
    }

    async function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    let counter0;
    let paused1 = true;
    counter0 = fetch(`http://localhost:5001/setID?id=${document.querySelector('input[name="options"]:checked').value}123abc${document.getElementById("startID").value}`)
        .then(function (response) {
            if (response.ok) {
                return response.text();
            }
            throw new Error('Network response was not ok.');
        })
        .then(function (data) {
            // data is the counter
            paused1 = false;
            counter0 = data;
            return data;
        }
        );

    while (paused1) {
        await sleep(300);
        console.log("paused1 as waiting for counter")
        continue;
    }


    await Option1firstActivity();

    await checkIfTabLoading();

    while (statusdiv.textContent.slice(0, 3) != "0l:") {
        if (checkTimeout()) {
            return false;
        }

        if (statusdiv.textContent.slice(0, 3) == "0s:") {
            await sleep(300);
            continue;
        }

        await checkIfTabLoading();
        await sleep(300);

    }


    await Option1CheckPostFirst();

    while (statusdiv.textContent.slice(0, 3) != "1c:") {
        if (statusdiv.textContent.slice(0, 3) == "1p:") { 
            await sleep(300);
            continue;
        }
        await Option1CheckPostFirst();
        await sleep(300);
    }

    let pageOpportunityid = statusdiv.textContent.slice(3);

    if (document.getElementById("startID").value != pageOpportunityid) {
        console.log("not match!")
        return false;
    }


    await checkSpecial();

    while (statusdiv.textContent.slice(0, 6) == "1.8.0:" || statusdiv.textContent.slice(0,5) == "1,-8:") {
        if (checkTimeout()) {
            return false;
        }

        if (statusdiv.textContent.slice(0,5) == "1,-8:") {
            await checkSpecial();
            await sleep(300);
            continue;
        }

        console.log("check special not complete")

        await sleep(300);
    }


    if (statusdiv.textContent.slice(0, 4) == "1.8:") {
        await sleep(300);
        await second0Activity();

        while (statusdiv.textContent.slice(0, 3) != "1.9") { // wait for 1.0
            if (checkTimeout()) {
                return false;
            }
            console.log("2.0 activity not complete")
            await sleep(300);
        }

        await secondActivity();

        while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
            if (checkTimeout()) {
                return false;
            }
            console.log("second activity not complete")

            if (statusdiv.textContent.slice(0, 5) == "2,-1:") {
                break;
            }

            await sleep(300);

            // TODO
            // implement self-fixing to download button spoiling here if timer hits 20s?
            // click the first document button with this element:
            // document.getElementsByClassName("formColumns_COLUMN-TD")[2].getElementsByTagName("a")[0]
        }

        if (statusdiv.textContent.slice(0, 5) != "2,-1:") { //if got download button, then download sequence

            await thirdActivity();

            while (statusdiv.textContent.slice(0, 2) != "3:") { // wait for third activity to complete, third activity needs to be recalled to check if download is complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("third activity not complete")

                if (statusdiv.textContent == "2 : Waiting for download to start... (download button may be spoilt if it is taking long)" && parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                    await fixsecondActivity();
                    await sleep(300);
                    await secondActivity();
                    await sleep(300);

                    while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("second activity not complete")
                        await sleep(300);

                    }

                    continue

                }



                await thirdActivity();
                await sleep(300);
            }
            await sleep(300);
            await fourthActivity();

            while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("fourth activity not complete")

                if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                    await fourthActivity();
                }

                await sleep(300);
            }

            await fourth1Activity();

            while (statusdiv.textContent.slice(0, 3) != "4.2") { // wait for fourth activity to complete
                if (checkTimeout()) {
                    return false;
                }
                console.log("fourth 1 activity not complete")

                if (statusdiv.textContent.slice(0, 4) == "4.-1") { // try to call again because loading
                    await fourth1Activity();
                }

                else if (statusdiv.textContent.slice(0, 3) == "4.1") {

                    await second0Activity();

                    while (statusdiv.textContent.slice(0, 3) != "1.9") { // wait for 1.0
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("2.0 activity not complete")
                        await sleep(300);
                    }


                    await secondActivity();

                    while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("second activity not complete")
                        await sleep(300);

                        // TODO
                        // implement self-fixing to download button spoiling here if timer hits 20s?
                        // click the first document button with this element:
                        // document.getElementsByClassName("formColumns_COLUMN-TD")[2].getElementsByTagName("a")[0]
                    }

                    await thirdActivity();

                    while (statusdiv.textContent.slice(0, 2) != "3:") { // wait for third activity to complete, third activity needs to be recalled to check if download is complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("third activity not complete")

                        if (statusdiv.textContent == "2 : Waiting for download to start... (download button may be spoilt if it is taking long)" && parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                            await fixsecondActivity();
                            await sleep(300);
                            await secondActivity();
                            await sleep(300);

                            while (statusdiv.textContent.slice(0, 2) != "2:") { //wait for second activity to complete
                                if (checkTimeout()) {
                                    return false;
                                }
                                console.log("second activity not complete")
                                await sleep(300);

                            }

                            continue
                        }

                        await thirdActivity();
                        await sleep(300);
                    }
                    await sleep(300);
                    await fourthActivity();

                    while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                        if (checkTimeout()) {
                            return false;
                        }
                        console.log("fourth activity not complete")

                        if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                            await fourthActivity();
                        }

                        await sleep(300);
                    }

                    await fourth1Activity();

                }

                await sleep(300);
            }
        }

        await sleep(300);

        await corrigendumActivity();

        while (statusdiv.textContent.slice(0, 6) == "4,4,1:") { // wait for fourth activity to complete
            if (checkTimeout()) {
                return false;
            }
            console.log("corrigendum activity not complete")
            await sleep(300);
        }

        if (statusdiv.textContent.slice(0, 7) == "4,4,-1:") { // no need to do corrigendum activity

        } else {
            let numberOfCorrigendumButton = parseInt(document.getElementById("corrigendumcount").textContent);
            for (let i = 0; i < numberOfCorrigendumButton; i++) {
                await sleep(300);
                await corrigendum1Activity();

                while (statusdiv.textContent.slice(0, 6) == "4,6,1:") { // wait for fourth activity to complete
                    if (checkTimeout()) {
                        return false;
                    }
                    console.log("corrigendum 1 activity not complete")
                    await sleep(300);
                }

                await corrigendum2Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,7,1:") {
                    if (checkTimeout()) {
                        return false;
                    }
                    if (statusdiv.textContent.slice(0, 6) == "4,7,0:") { // wait for fourth activity to complete

                        console.log("corrigendum 2 activity not complete")
                        await sleep(300);
                        continue
                    }
                    if (statusdiv.textContent.slice(0, 7) == "4,7,-1:") { // need to call again
                        await sleep(300);
                        if (parseInt(document.getElementById("timerforstatus").textContent) >= 15) {
                            fetch("http://localhost:5001/decrementcorricounter");
                            await sleep(300);
                            await corrigendum1Activity();

                            while (statusdiv.textContent.slice(0, 6) == "4,6,1:") { // wait for fourth activity to complete
                                if (checkTimeout()) {
                                    return false;
                                }
                                console.log("corrigendum 1 activity not complete")
                                await sleep(300);
                            }
                            await corrigendum2Activity();
                            continue
                        }
                        await corrigendum2Activity();
                        continue
                    }
                    await sleep(300);
                }

                await corrigendum3Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,8,2:") {
                    console.log("waiting for corri 3 activity here")
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 7) == "4,8,-1:") { // activity exited, call again
                        await sleep(300);
                        await corrigendum3Activity();
                        continue
                    }

                    await sleep(300);
                }

                await corrigendum4Activity();

                while (statusdiv.textContent.slice(0, 6) != "4,9,3:") {
                    console.log("waiting for corri 4 here")
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,0:") { // wait for fourth activity to complete
                        console.log("corrigendum 4 activity not complete")
                        await sleep(300);
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,1:" || statusdiv.textContent.slice(0, 5) == "4,8,2") { // wait for fourth activity to complete
                        console.log("corrigendum 4 activity not complete 2")
                        if (parseInt(document.getElementById("timerforstatus").textContent) >= 48) {
                            await fixcorrigendum3Activity();

                            while (statusdiv.textContent.slice(0, 8) != "4,8,9,1:") {
                                console.log("waiting for fix corri 3 activity here")
                                if (checkTimeout()) {
                                    return false;
                                }
                                await sleep(300);
                            }

                            await sleep(300);
                            await corrigendum3Activity();
                            await sleep(300);
                            continue;
                        }
                        // await fixcorrigendum3Activity();
                        await sleep(300);
                        await corrigendum4Activity();
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 6) == "4,9,2:") { // wait for fourth activity to complete
                        await corrigendum4Activity();
                        await sleep(300);
                        continue;
                    }

                    await sleep(300);

                }

                // send corrigendum folder back

                await fourthActivity();

                while (statusdiv.textContent.slice(0, 2) != "4:") { // wait for fourth activity to complete
                    if (checkTimeout()) {
                        return false;
                    }
                    console.log("fourth activity not complete")

                    if (statusdiv.textContent.slice(0, 3) == "3.9") { // try to send over the file again because error
                        await fourthActivity();
                    }

                    await sleep(300);
                }

                await corrigendum5Activity();

                while (statusdiv.textContent.slice(0, 7) != "4,10,1:") {
                    if (checkTimeout()) {
                        return false;
                    }
                    await sleep(300);
                }

                await corrigendum6Activity();

                while (statusdiv.textContent.slice(0, 7) != "4,11,1:") {
                    if (checkTimeout()) {
                        return false;
                    }

                    if (statusdiv.textContent.slice(0, 7) == "4,11,0:") { // wait for fourth activity to complete
                        console.log("corrigendum 6 activity not complete")
                        await sleep(300);
                        continue;
                    }

                    if (statusdiv.textContent.slice(0, 8) == "4,11,-1:") { // not back, call again
                        await corrigendum6Activity();
                        await sleep(300);
                        continue;
                    }

                    await sleep(300);

                }

            }
        }



        await fifthActivity();

        while (statusdiv.textContent.slice(0, 4) != "5.a:") { // wait for fifth activity to complete
            if (checkTimeout()) {
                return false;
            }

            if (statusdiv.textContent.slice(0, 3) == "5s:") { // wait for fifth activity to complete
                await sleep(300);
                continue;
            }

            if (parseInt(document.getElementById("timerforstatus").textContent) >= 10 && statusdiv.textContent.slice(0, 2) == "5:") {
                await fifthActivity();
                await sleep(300);
                continue;
            }

            console.log("fifth activity not complete")
            await sleep(300);
        }

        await bidsOwnActivity();

        while (!(statusdiv.textContent.slice(0, 6) == "4,o,1:" || statusdiv.textContent.slice(0,7) == "4,o,-1:")) { 
            
            if (checkTimeout()) {
                return false;
            }

            if (statusdiv.textContent.slice(0, 6) == "4,o,0:") {
                await sleep(300);
                continue;
            }

            await bidsOwnActivity();
            await sleep(300);
        }

        if (statusdiv.textContent.slice(0, 6) == "4,o,1:") {
            await sleep(300);
            await bidsOwnActivity1();

            while (statusdiv.textContent.slice(0, 6) != "4,o,3:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,2:") {
                    await sleep(300);
                    continue;
                }

                await bidsOwnActivity1();
                await sleep(300);
            }

            await sleep(300);

            await bidsOwnActivity2();

            while (statusdiv.textContent.slice(0, 6) != "4,o,5:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,4:") {
                    await sleep(300);
                    continue;
                }

                await bidsOwnActivity2();
                await sleep(300);
            }

            await sleep(300);

            await exitVSR();
            
            while (statusdiv.textContent.slice(0, 6) != "4,o,7:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 6) == "4,o,6:") {
                    await sleep(300);
                    continue;
                }

                await exitVSR();
                await sleep(300);
            }

            await corrigendum6Activity();

            while (statusdiv.textContent.slice(0, 7) != "4,11,1:") {
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 7) == "4,11,0:") { // wait for fourth activity to complete
                    console.log("corrigendum 6 activity not complete")
                    await sleep(300);
                    continue;
                }

                if (statusdiv.textContent.slice(0, 8) == "4,11,-1:") { // not back, call again
                    await corrigendum6Activity();
                    await sleep(300);
                    continue;
                }

                await sleep(300);

            }


        }

        await five0Activity();

        while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
            if (checkTimeout()) {
                return false;
            }
            if (statusdiv.textContent.slice(0, 3) == "5.3") {
                break;
            }
            if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                await sleep(300);
                continue;
            }
            await five0Activity();
            console.log("5.0 activity not complete")
            await sleep(300);
        }

        await sleep(100);

        if (statusdiv.textContent.slice(-1) == "3") {
            await five2Activity();

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

            await five0Activity();

            while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
                if (checkTimeout()) {
                    return false;
                }
                if (statusdiv.textContent.slice(0, 3) == "5.3") {
                    break;
                }
                if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                    await sleep(300);
                    continue;
                }
                await five0Activity();
                console.log("5.0 activity not complete")
                await sleep(300);
            }
        }



        if (statusdiv.textContent.slice(-1) == "1") {
            await sleep(300);
            await five1Activity();

            while (statusdiv.textContent.slice(0, 5) != "5.1a:") { // wait for 5.1
                if (checkTimeout()) {
                    return false;
                }

                if (statusdiv.textContent.slice(0, 5) == "5a-1:") { // need to call again
                    await five1Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.1a activity not complete")
                await sleep(300);
            }

            console.log(statusdiv.textContent)
            console.log("calling five 0")
            await five0Activity();

            while (statusdiv.textContent.slice(0, 3) != "5.0") { // wait for 5.0
                if (checkTimeout()) {
                    return false;
                }
                if (statusdiv.textContent.slice(0, 3) == "5.3") {
                    break;
                }
                if (statusdiv.textContent.slice(0, 6) == "5,0ip:") {
                    await sleep(300);
                    continue;
                }
                await five0Activity();
                console.log("5.0 activity not complete")
                await sleep(300);
            }

        }





        if (statusdiv.textContent.slice(-1) == "2") {
            await five2Activity();
            await sleep(300);

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

        }

        if (statusdiv.textContent.slice(-1) == "3") {
            await five2Activity();
            await sleep(300);

            while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
                if (checkTimeout()) {
                    return false;
                }


                if (statusdiv.textContent.slice(0, 5) == "5a-2:") { // need to call again
                    await five2Activity();
                    await sleep(300);
                    continue
                }

                console.log("5.2a activity not complete")
                await sleep(300);
            }

        }

    } else {
        // special case, awards page is first page
        await five2SpecialActivity();

        while (statusdiv.textContent.slice(0, 5) != "5.2a:") { // wait for 5.2
            if (checkTimeout()) {
                return false;
            }


            console.log("5.2a activity not complete")
            await sleep(300);
        }

    }
    await sleep(300);

    let lastcounter;
    let paused = true;
    lastcounter = fetch('http://localhost:5001/getcounterstatic')
        .then(function (response) {
            if (response.ok) {
                return response.text();
            }
            throw new Error('Network response was not ok.');
        })
        .then(function (data) {
            // data is the counter
            paused = false;
            lastcounter = data;
            return data;
        }
        );

    while (paused) {
        await sleep(300);
        console.log("paused as waiting for lastcounter")
        continue;
    }

    document.getElementById("lastIndexCounter").textContent = lastcounter;
    document.getElementById("numberCompleted").innerText = parseInt(document.getElementById("numberCompleted").innerText) + 1;

    return false;

}

async function buttonClick() {

    document.getElementById("clickme").disabled = true;
    document.getElementById("startcounter").disabled = true;
    document.getElementById("option").disabled = true;
    document.getElementById("startID").disabled = true;
    document.getElementsByName("options")[0].disabled = true;
    document.getElementsByName("options")[1].disabled = true;
    document.getElementsByName("options")[2].disabled = true;

    async function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }


    await fetch("http://localhost:5001/setcounter?counter=" + document.getElementById("startcounter").value);
    await sleep(300);

    // if option1 is selected, then we only do 1 tender
    if (document.getElementById("option").value == "option1") {
        await getOnlyOneOpportunity();
        await sleep(300);
    } else {
        // full crawl

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {

            // inject script into current tab
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                function: async () => {
                    // return true if url is "https://www.gebiz.gov.sg/ptn/invitations/InvListing.xhtml" or "https://www.gebiz.gov.sg/ptn/response/ResponseListing.xhtml"
                    if (window.location.href == "https://www.gebiz.gov.sg/ptn/invitations/InvListing.xhtml" || window.location.href == "https://www.gebiz.gov.sg/ptn/response/ResponseListing.xhtml") {
                        return true;
                    } else {
                        return false;
                    }
                    
                }
            }, async function (result) {
    
                if (result[0].result == null) {
                    statusdiv.textContent = "Failed to start full crawl, please try again";
                    return;
                }
    
                if (result[0].result == true) {
                    statusdiv.textContent = "Starting full crawl";
                } else if (result[0].result == false) {
                    statusdiv.innerHTML = `Failed to start full crawl, please start at Invitations or Responses page:<br><br>
                    Invitations: https://www.gebiz.gov.sg/ptn/invitations/InvListing.xhtml<br>
                    Responses: https://www.gebiz.gov.sg/ptn/response/ResponseListing.xhtml
                    `;
                    return;
                }
    
            })
        });

        while (true) {
            if (statusdiv.textContent.includes("full crawl")) {
                break;
            }
            await sleep(300);
        }

        if (!statusdiv.textContent.includes("Starting full crawl")) {
            return;
        }

        while (await getOneOpportunity()) {
            console.log("getting next opportunity")
            await fetch("http://localhost:5001/resetcorricounter");
            await sleep(300);
        }
    }

    

    if (statusdiv.textContent == "timed out") {
        return;
    }
    statusdiv.textContent = "done";


}

var oldstatus = "initial";

document.getElementById("clickme").addEventListener("click", buttonClick);

async function countTimer() {

    async function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    while (true) {
        await sleep(1000);
        if (statusdiv.textContent == "") {
            continue;
        }
        if (statusdiv.textContent == "done") {
            document.getElementById("timerforstatus").textContent = ""
            break;
        }
        if (oldstatus != statusdiv.textContent) {
            document.getElementById("timerforstatus").textContent = 0
            oldstatus = statusdiv.textContent;
        }
        else {
            document.getElementById("timerforstatus").textContent = parseInt(document.getElementById("timerforstatus").textContent) + 1

            if (document.getElementById("timerforstatus").textContent == 60 && statusdiv.textContent != "2 : Waiting for download to complete...") {
                if (statusdiv.textContent != "timed out") {

                    if (statusdiv.textContent.slice(0, 2) == "12:") {
                        document.getElementById("resolvemsg").textContent = "File name remained the same, please check if the 'Download All' button works"
                    }
                    else {
                        document.getElementById("resolvemsg").textContent = "Please check if set up is correct, or whether website is behaving correctly like showing correct responses."
                    }

                    document.getElementById("timedoutstatus").textContent = statusdiv.textContent;
                    statusdiv.textContent = "timed out"
                }



            }

        }

    }
}

// reset counter by sending a get request to http://localhost:5001/resetcounter
async function resetCounter() {
    await fetch("http://localhost:5001/resetcounter");
}

// if select id "option" is changed, then hide or show the divs
document.getElementById("option").addEventListener("change", function () {
    if (document.getElementById("option").value == "option1") {
        document.getElementById("option1DIV").style.display = "block";
        document.getElementById("option2DIV").style.display = "none";
        document.getElementById("option2LastCompleted").style.display = "none";
    }
    else {
        document.getElementById("option1DIV").style.display = "none";
        document.getElementById("option2DIV").style.display = "block";
        document.getElementById("option2LastCompleted").style.display = "block";
    }

});

// make a call to http://localhost:5001/getcounterstatic to see if server is running
// send request_dict to server here
fetch('http://localhost:5001/getcounterstatic')
    .then(data => {
        document.getElementById("runservercheck").textContent = "Server is running";
        document.getElementById("clickme").disabled = false;
    })
    .catch((error) => {
        console.error('Error:', error);
        document.getElementById("clickme").disabled = true;
        document.getElementById("runservercheck").textContent = "Please execute runserver.py first, and reopen extension.";
    }
    );


resetCounter();


countTimer();




