from flask import Flask, request
from flask_cors import CORS
import requests
import os
import socket
import tkinter as tk
from tkinter import messagebox
import ctypes

app = Flask(__name__)
CORS(app)

counter = 0
corricounter = 0
opportunity_id = ""

url = "http://122.248.201.55:8080/api/v1"
logintoken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFjY2VudHVyZSIsImlhdCI6MTY4NjI4Mjc0MX0.72cZoasvRf8OD1T4scSMlBEClkPH2QUXoK2or1jkbvY'

def is_port_available(port):
    try:
        # Create a socket and try to bind it to the specified port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', port))
        return True
    except OSError:
        # The port is already in use
        return False

@app.route('/sendfile', methods=['GET'])
def sendfile():
    global url
    global logintoken

    # url = 'http://localhost:8080/api/v1/download'
    endurl = url + '/download'
    # logintoken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImFjY2VudHVyZSIsImlhdCI6MTY4NjI3NjYwNn0.TUAmvtcDNk6Q9RioxyySfvfch_MPimGz7O2KwYYP7jE'
    
    
    # get filename from request
    filename = request.args.get('filename')
    print(filename)
    # replace "//" with "\" in filename
    filename = filename.replace("//", "\\")
    upload_file = {'file': open(f'{filename}', 'rb')}
    headers = {
                'Authorization': 'Bearer ' + logintoken,
            }
    response = requests.post(endurl, files=upload_file, headers=headers)
    # response = requests.post(url, files=upload_file)

    print(response.text)
        



    return "Success"

@app.route('/deletefile')
def deletefile():
    # get filename from request
    filename = request.args.get('filename')
    print(filename)
    # replace "//" with "\" in filename
    filename = filename.replace("//", "\\")
    os.remove(filename)

    return "Success"



@app.route('/setID')
def setID():
    global opportunity_id

    # get opportunity_id from get request
    opportunity_id = request.args.get('id')
    print(opportunity_id)

    return "Success"

@app.route('/getID')
def getID():
    global opportunity_id

    print(opportunity_id)

    return opportunity_id




@app.route('/resetcounter')
def reset_counter():
    global counter
    global corricounter

    corricounter = 0
    counter = 0
    print("counter resetted")
    return "Success"

@app.route('/setcounter')
def set_counter():
    global counter

    # get counter from get request
    counter = int(request.args.get('counter')) - 1
    print(counter)
    
    return "Success"

@app.route('/resetcorricounter')
def reset_corricounter():
    global corricounter

    corricounter = 0
    print("corricounter resetted")
    return "Success"

@app.route('/decrementcorricounter')
def decrement_corricounter():
    global corricounter

    corricounter -= 1
    print(corricounter)

    return str(corricounter)

@app.route('/checkcounter')
def check_counter():
    global counter

    counter += 1
    print(counter)

    return str(counter)

@app.route('/getcounterstatic')
def get_counter_static():
    global counter
    print("static counter: " + str(counter))
    return str(counter)

@app.route('/checkcorricounter')
def check_corricounter():
    global corricounter

    corricounter += 1
    print(corricounter)

    return str(corricounter)


if __name__ == '__main__':
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0) #hide console
    # Set the port you want to use for your Flask application
    desired_port = 5001

    if is_port_available(desired_port):
        app.run(port=desired_port)

    else:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Port in Use", f"Port {desired_port} is already in use. Cannot start the Flask application.\nIt may have already been started!")

